#!/usr/bin/env python3
"""KIRC0: public GDC metadata inventory, isolated from all completed analyses.

Python 3.10+, standard library only. No CLI flags. Put this file in the project's
paper5_parallel_kirc directory. Queries only https://api.gdc.cancer.gov/files.
No molecular payload, model, outcome, historical result, or package access.

This is a NEW post-SARC feasibility snapshot. It does not authorize acquisition
or model fitting, select a final cohort, or retroactively preregister results.
Matching summaries are conservative diagnostics, not a download manifest.

References (retrieved 2026-10-10):
https://docs.gdc.cancer.gov/API/Users_Guide/Search_and_Retrieval/
https://docs.gdc.cancer.gov/Encyclopedia/pages/TCGA_Barcode/
https://docs.gdc.cancer.gov/Data/Bioinformatics_Pipelines/CNV_Pipeline/
"""
from __future__ import annotations

import csv
import hashlib
import http.client
import io
import json
import re
import socket
import stat
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

VERSION = "kirc0-isolated-gdc-metadata-hm450-ascat3-link-audit-v1-no-fit"
PROJECT = "TCGA-KIRC"
FOLDER_NAME = "paper5_parallel_kirc"
ENDPOINT = "https://api.gdc.cancer.gov/files"
PAGE_SIZE = 200
MAX_FILES_PER_TYPE = 10000
MAX_RESPONSE_BYTES = 16 * 1024 * 1024
MAX_EVIDENCE_BYTES = 5 * 1024 * 1024
TIMEOUT_SECONDS = 45
ATTEMPTS = 4
KINDS = {
    "RNA": "Gene Expression Quantification",
    "METHYLATION": "Methylation Beta Value",
    "CNV": "Gene Level Copy Number",
}
TARGET_WORKFLOWS = {
    "RNA": "STAR - Counts",
    "METHYLATION": "SeSAMe Methylation Beta Estimation",
    "CNV": "ASCAT3",
}
TARGET_STRATEGIES = {
    "RNA": "RNA-Seq", "METHYLATION": "Methylation Array", "CNV": "Genotyping Array",
}
# Same explicitly projected metadata fields used by the successful SARC inventory.
# No expand=cases, no clinical endpoints, no diagnoses/demographic fields.
FIELDS = (
    "file_id", "file_name", "file_size", "md5sum", "data_type", "data_category",
    "data_format", "platform", "access", "state", "experimental_strategy",
    "analysis.workflow_type", "cases.case_id", "cases.submitter_id",
    "cases.project.project_id", "cases.samples.sample_id",
    "cases.samples.submitter_id", "cases.samples.sample_type",
    "associated_entities.case_id", "associated_entities.entity_id",
    "associated_entities.entity_submitter_id", "associated_entities.entity_type",
)
UUID_RE = re.compile(r"[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\Z")
CASE_RE = re.compile(r"TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}\Z")
ALIQUOT_RE = re.compile(
    r"(?P<case>TCGA-[A-Z0-9]{2}-[A-Z0-9]{4})-"
    r"(?P<sample_code>[0-9]{2})(?P<vial>[A-Z])-"
    r"(?P<portion>[0-9]{2})(?P<analyte>[A-Z])-"
    r"(?P<plate>[A-Z0-9]{4})-(?P<center>[0-9]{2})\Z"
)
SENSITIVE_KEYS = {
    "diagnoses", "diagnosis", "demographic", "demographics", "treatments",
    "follow_ups", "followups", "exposures", "vital_status", "days_to_death",
    "days_to_last_follow_up", "survival", "outcomes", "clinical", "disease_type",
}


class InventoryError(RuntimeError):
    """Fail closed without editing the existing project."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise InventoryError(message)


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False,
                       allow_nan=False) + "\n").encode("utf-8")


def write_new(path: Path, data: bytes) -> None:
    with path.open("xb") as handle:
        handle.write(data)


def write_json(path: Path, value: Any) -> None:
    write_new(path, json_bytes(value))


def csv_bytes(rows: list[dict[str, Any]], fields: list[str]) -> bytes:
    out = io.StringIO(newline="")
    writer = csv.DictWriter(out, fieldnames=fields, lineterminator="\n", extrasaction="raise")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: json.dumps(value, separators=(",", ":"), ensure_ascii=False)
                         if isinstance(value, (list, dict)) else value
                         for key, value in row.items()})
    return out.getvalue().encode("utf-8")


def record_file(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    return {"size_bytes": len(data), "sha256": sha(data)}


def plain_directory(path: Path) -> None:
    info = path.lstat()
    reparse = getattr(info, "st_file_attributes", 0) & getattr(
        stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and not reparse,
            f"Not a regular, non-linked directory: {path}")


def base_directory(script: Path) -> Path:
    script = script.absolute()
    require(script.name == "kirc0.py", "Keep the extracted file name kirc0.py unchanged")
    require(script.parent.name == FOLDER_NAME,
            f"Extract into {FOLDER_NAME}, not paper5/scripts or paper5_parallel_sarc")
    plain_directory(script.parent)
    plain_directory(script.parent.parent)
    require((script.parent.parent / "paper5").is_dir(),
            "Expected paper5 next to paper5_parallel_kirc; check the extraction directory")
    info = script.lstat()
    require(stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode),
            "Source must be a regular file")
    return script.parent


def project_filter(data_type: str) -> dict[str, Any]:
    require(data_type in KINDS.values(), "Unapproved data type")
    return {"op": "and", "content": [
        {"op": "in", "content": {"field": "cases.project.project_id", "value": [PROJECT]}},
        {"op": "in", "content": {"field": "data_type", "value": [data_type]}},
        {"op": "in", "content": {"field": "access", "value": ["open"]}},
    ]}


def query_params(data_type: str, offset: int) -> dict[str, Any]:
    require(type(offset) is int and offset >= 0, "Invalid page offset")
    return {"filters": json.dumps(project_filter(data_type), separators=(",", ":")),
            "fields": ",".join(FIELDS), "format": "JSON", "size": PAGE_SIZE,
            "from": offset, "sort": "file_id:asc"}


def valid_endpoint(url: str) -> bool:
    parts = urllib.parse.urlsplit(url)
    return (parts.scheme == "https" and parts.netloc == "api.gdc.cancer.gov"
            and parts.path in ("/files", "/files/") and not parts.fragment)


class MetadataRedirectsOnly(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req: Any, fp: Any, code: int, msg: str,
                         headers: Any, newurl: str) -> Any:
        # Check BEFORE following a redirect, not after contacting another endpoint.
        require(valid_endpoint(newurl), "Redirect outside the GDC /files metadata endpoint blocked")
        require(urllib.parse.parse_qs(urllib.parse.urlsplit(newurl).query) ==
                urllib.parse.parse_qs(urllib.parse.urlsplit(req.full_url).query),
                "Redirect changed the projected metadata query")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def reject_sensitive(value: Any) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            require(str(key).lower() not in SENSITIVE_KEYS,
                    "Server returned an unrequested sensitive metadata field; body not saved")
            reject_sensitive(item)
    elif isinstance(value, list):
        for item in value:
            reject_sensitive(item)


def fetch_page(params: dict[str, Any], event: Callable[[dict[str, Any]], None],
               opener: Any = None, sleeper: Callable[[float], None] = time.sleep
               ) -> tuple[bytes, dict[str, Any]]:
    url = ENDPOINT + "?" + urllib.parse.urlencode(params)
    require(valid_endpoint(url), "Only public GDC file metadata queries are allowed")
    request = urllib.request.Request(url, headers={
        "User-Agent": "Paper5-KIRC-metadata-inventory/1.0",
        "Accept": "application/json", "Accept-Encoding": "identity",
    })
    if opener is None:
        opener = urllib.request.build_opener(MetadataRedirectsOnly())
    last_error: Exception | None = None
    for attempt in range(1, ATTEMPTS + 1):
        retry_after: str | None = None
        try:
            with opener.open(request, timeout=TIMEOUT_SECONDS) as response:
                require(valid_endpoint(response.geturl()), "Unexpected final metadata URL")
                require(response.getcode() == 200, "Unexpected successful HTTP status")
                content_type = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                require(content_type == "application/json" or content_type.endswith("+json"),
                        "Expected JSON metadata, not a downloaded file or HTML page")
                require(response.headers.get("Content-Encoding", "identity").lower() in ("", "identity"),
                        "Unexpected compressed transport response")
                size = response.headers.get("Content-Length")
                if size is not None:
                    require(size.isdigit() and int(size) <= MAX_RESPONSE_BYTES,
                            "Invalid/excessive metadata Content-Length")
                body = response.read(MAX_RESPONSE_BYTES + 1)
                require(len(body) <= MAX_RESPONSE_BYTES, "Metadata page exceeds size cap")
                if size is not None and len(body) != int(size):
                    raise http.client.IncompleteRead(body, int(size) - len(body))
                try:
                    value = json.loads(body.decode("utf-8-sig"))
                except (ValueError, UnicodeError) as exc:
                    raise InventoryError("Invalid JSON metadata; no successful result inferred") from exc
                require(isinstance(value, dict), "GDC returned a non-object response")
                reject_sensitive(value)
                event({"at_utc": utc(), "attempt": attempt, "status": "HTTP_METADATA_RECEIVED",
                       "response_bytes": len(body), "response_sha256": sha(body),
                       "server_date": response.headers.get("Date"),
                       "etag": response.headers.get("ETag")})
                return body, value
        except urllib.error.HTTPError as exc:
            retry_after = exc.headers.get("Retry-After") if exc.headers else None
            code = exc.code
            exc.close()
            if code not in (408, 429, 500, 502, 503, 504):
                raise InventoryError(f"GDC HTTP {code}; query not silently changed") from exc
            last_error = exc
        except (urllib.error.URLError, TimeoutError, socket.timeout,
                ConnectionError, http.client.RemoteDisconnected, http.client.IncompleteRead) as exc:
            last_error = exc
        event({"at_utc": utc(), "attempt": attempt, "status": "NETWORK_RETRY_OR_STOP",
               "error_type": type(last_error).__name__, "error": str(last_error)[:1500]})
        if attempt < ATTEMPTS:
            delay = float(5 * (2 ** (attempt - 1)))
            if retry_after and retry_after.isdigit():
                delay = max(delay, min(120.0, float(retry_after)))
            print(f"Metadata network retry {attempt}/{ATTEMPTS}: wait {delay:g}s", flush=True)
            sleeper(delay)
    raise InventoryError(f"GDC metadata unavailable after {ATTEMPTS} attempts: {last_error}")


def validate_hit(hit: Any, data_type: str) -> dict[str, Any]:
    require(isinstance(hit, dict), "File hit is not an object")
    fid = hit.get("file_id") or hit.get("id")
    require(isinstance(fid, str) and UUID_RE.fullmatch(fid) is not None, "Invalid file UUID")
    require(hit.get("data_type") == data_type and hit.get("access") == "open",
            f"Unexpected type/access for {fid}")
    require(type(hit.get("file_size")) is int and hit["file_size"] >= 0,
            f"Missing/invalid file size: {fid}")
    require(isinstance(hit.get("file_name"), str) and bool(hit["file_name"]), "Missing file name")
    # Missing checksums are retained as a review issue, NEVER a usable download binding.
    md5 = hit.get("md5sum")
    require(md5 is None or isinstance(md5, str), "Malformed MD5 field")
    cases = hit.get("cases")
    require(isinstance(cases, list) and bool(cases), f"No cases attached to {fid}")
    projected_cases = []
    seen = set()
    for case in cases:
        require(isinstance(case, dict), "Malformed case")
        cid, barcode = case.get("case_id"), case.get("submitter_id")
        require(isinstance(cid, str) and UUID_RE.fullmatch(cid) is not None, "Invalid case UUID")
        require(isinstance(barcode, str) and CASE_RE.fullmatch(barcode) is not None, "Invalid case barcode")
        require(cid not in seen, "Repeated case node in one file")
        seen.add(cid)
        require((case.get("project") or {}).get("project_id") == PROJECT,
                f"Missing/foreign project in metadata: {fid}")
        samples = case.get("samples") or []
        require(isinstance(samples, list), "Malformed samples collection")
        projected_samples = []
        for sample in samples:
            require(isinstance(sample, dict), "Malformed sample")
            projected_samples.append({k: sample.get(k) for k in
                                      ("sample_id", "submitter_id", "sample_type")})
        projected_cases.append({"case_id": cid, "submitter_id": barcode,
                                "project": {"project_id": PROJECT}, "samples": projected_samples})
    entities = hit.get("associated_entities") or []
    require(isinstance(entities, list) and all(isinstance(e, dict) for e in entities),
            "Malformed associated_entities")
    analysis = hit.get("analysis") or {}
    require(isinstance(analysis, dict), "Malformed analysis metadata")
    record = {k: hit.get(k) for k in (
        "file_name", "file_size", "md5sum", "data_type", "data_category", "data_format",
        "platform", "access", "state", "experimental_strategy")}
    record.update({"file_id": fid, "analysis": {"workflow_type": analysis.get("workflow_type")},
                   "cases": projected_cases, "associated_entities": [
                       {k: e.get(k) for k in ("case_id", "entity_id", "entity_submitter_id", "entity_type")}
                       for e in entities]})
    return record


def collect_type(kind: str, run: Path, transport: Any = fetch_page) -> list[dict[str, Any]]:
    data_type = KINDS[kind]
    records: list[dict[str, Any]] = []
    seen: set[str] = set()
    offset, expected_total = 0, None
    while True:
        tag = f"{kind.lower()}_{offset:06d}"
        params = query_params(data_type, offset)
        write_json(run / f"{tag}_request.json", {"endpoint": ENDPOINT, "parameters": params,
                                                "requested_at_utc": utc()})
        with (run / f"{tag}_network.jsonl").open("xb") as log:
            def event(value: dict[str, Any]) -> None:
                log.write((json.dumps(value, sort_keys=True, allow_nan=False) + "\n").encode())
                log.flush()
            body, response = transport(params, event)
        write_new(run / f"{tag}_response.json", body)
        require(not response.get("errors") and not response.get("error"), "API returned errors")
        require(not response.get("warnings"), "GDC returned query warnings; inspect the saved page")
        data = response.get("data")
        require(isinstance(data, dict), "Missing response data object")
        hits, pagination = data.get("hits"), data.get("pagination")
        require(isinstance(hits, list) and isinstance(pagination, dict), "Invalid pagination schema")
        total = pagination.get("total")
        require(type(total) is int and 0 <= total <= MAX_FILES_PER_TYPE, "Invalid/excessive total")
        if expected_total is None:
            expected_total = total
        require(total == expected_total, "Inventory total changed between pages; no mixed snapshot accepted")
        require(type(pagination.get("from")) is int and pagination["from"] == offset,
                "Response page offset differs from request")
        require(type(pagination.get("count")) is int and pagination["count"] == len(hits),
                "Response page count differs from hits")
        require(len(hits) <= PAGE_SIZE and offset + len(hits) <= total, "Invalid page length")
        for hit in hits:
            record = validate_hit(hit, data_type)
            key = record["file_id"].lower()
            require(key not in seen, "Repeated file UUID across pages")
            if records:
                require(key > records[-1]["file_id"].lower(), "file_id:asc ordering not respected")
            seen.add(key)
            records.append(record)
        offset += len(hits)
        print(f"{kind}: metadata records {offset}/{total}", flush=True)
        if offset == total:
            break
        require(bool(hits), "Empty page before advertised total")
    write_json(run / f"{kind.lower()}_files.json", records)
    return records


def token(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def methylation_platform(value: Any) -> str:
    t = token(value)
    if t in {"illuminahumanmethylation450", "illuminahumanmethylation450k",
             "humanmethylation450", "humanmethylation450k", "hm450", "hm450k"}:
        return "HM450"
    if t in {"illuminahumanmethylation27", "illuminahumanmethylation27k",
             "humanmethylation27", "humanmethylation27k", "hm27", "hm27k"}:
        return "HM27"
    return "OTHER_OR_UNKNOWN"


def target_workflow_issues(kind: str, record: dict[str, Any]) -> list[str]:
    issues = []
    if (record.get("analysis") or {}).get("workflow_type") != TARGET_WORKFLOWS[kind]:
        issues.append("NOT_REQUESTED_WORKFLOW")
    if record.get("experimental_strategy") != TARGET_STRATEGIES[kind]:
        issues.append("NOT_REQUESTED_STRATEGY")
    if record.get("state") != "released":
        issues.append("NOT_RELEASED")
    if kind == "METHYLATION" and methylation_platform(record.get("platform")) != "HM450":
        issues.append("NOT_HM450")
    if kind == "CNV" and token(record.get("platform")) != "affymetrixsnp60":
        issues.append("NOT_SNP6")
    if re.fullmatch(r"[0-9a-fA-F]{32}", str(record.get("md5sum", ""))) is None:
        issues.append("MISSING_OR_INVALID_MD5")
    if record.get("file_size", 0) <= 0:
        issues.append("ZERO_FILE_SIZE")
    return issues


def file_links(kind: str, record: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str]]:
    """Resolve the ACTUALLY associated aliquot to the same-case sample node.

    Do not promote every sample under cases.samples to a file linkage. Portions
    below are barcode-derived, not independently verified portion UUIDs.
    """
    links, issues = [], []
    cases = {c["case_id"]: c for c in record["cases"]}
    if len(cases) != 1:
        issues.append("MULTIPLE_CASES_ON_FILE")
    entities = record.get("associated_entities") or []
    if not entities:
        issues.append("NO_ASSOCIATED_ENTITIES")
    seen_entities = set()
    for entity in entities:
        eid = entity.get("entity_id")
        if not isinstance(eid, str) or UUID_RE.fullmatch(eid) is None:
            issues.append("INVALID_ASSOCIATED_ENTITY_UUID")
            continue
        if eid in seen_entities:
            issues.append("DUPLICATE_ASSOCIATED_ENTITY")
            continue
        seen_entities.add(eid)
        if entity.get("entity_type") != "aliquot":
            issues.append("UNSUPPORTED_ASSOCIATED_ENTITY_TYPE")
            continue
        match = ALIQUOT_RE.fullmatch(str(entity.get("entity_submitter_id", "")))
        if match is None:
            issues.append("UNRESOLVED_ALIQUOT_BARCODE")
            continue
        case = cases.get(entity.get("case_id"))
        if case is None or case["submitter_id"] != match["case"]:
            issues.append("ASSOCIATED_ENTITY_CASE_MISMATCH")
            continue
        sample_barcode = f"{match['case']}-{match['sample_code']}{match['vial']}"
        samples = [s for s in case["samples"] if s.get("submitter_id") == sample_barcode]
        if len(samples) != 1:
            issues.append("SAMPLE_NODE_NOT_UNIQUE_OR_ABSENT")
            continue
        sample = samples[0]
        sid = sample.get("sample_id")
        if not isinstance(sid, str) or UUID_RE.fullmatch(sid) is None:
            issues.append("INVALID_SAMPLE_UUID")
            continue
        code_primary = match["sample_code"] == "01"
        type_primary = sample.get("sample_type") == "Primary Tumor"
        if code_primary != type_primary:
            issues.append("PRIMARY_CODE_AND_SAMPLE_TYPE_DISAGREE")
            continue
        links.append({
            "modality": kind, "file_id": record["file_id"], "case_id": case["case_id"],
            "case_barcode": case["submitter_id"], "sample_id": sid,
            "sample_barcode": sample_barcode, "sample_type": sample.get("sample_type"),
            "sample_code": match["sample_code"], "primary_tumor": code_primary and type_primary,
            "portion_barcode": sample_barcode + "-" + match["portion"],
            "portion_link_basis": "DERIVED_FROM_ASSOCIATED_ALIQUOT_BARCODE_NOT_PORTION_UUID",
            "analyte_code": match["analyte"], "aliquot_id": eid,
            "aliquot_barcode": entity["entity_submitter_id"],
        })
    primary = [link for link in links if link["primary_tumor"]]
    if len(primary) != 1:
        issues.append("NO_UNIQUE_PRIMARY_TUMOR_ALIQUOT")
    if kind != "CNV" and len(entities) != 1:
        issues.append("NON_CNV_FILE_HAS_MULTIPLE_ENTITIES")
    return links, sorted(set(issues))


def make_summary(all_records: dict[str, list[dict[str, Any]]]) -> tuple[dict[str, Any], dict[str, Any]]:
    require(set(all_records) == set(KINDS), "Incomplete modality inventory")
    all_file_ids = [r["file_id"] for rows in all_records.values() for r in rows]
    require(len(set(all_file_ids)) == len(all_file_ids), "File UUID repeated across data types")
    case_names: dict[str, str] = {}
    case_uuids: dict[str, str] = {}
    sample_names: dict[str, tuple[str, str]] = {}
    by_kind, case_sets, audits, links_out = {}, {}, [], []
    # Group ALL usable alternatives; no per-case first-file / highest-n selection.
    groups: dict[tuple[str, str, str, str, str], dict[str, set[str]]] = {}
    case_kind_files: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    for kind, records in all_records.items():
        workflows = Counter()
        fixed_files = 0
        issue_counts: Counter[str] = Counter()
        platforms: Counter[str] = Counter()
        per_case: Counter[str] = Counter()
        case_sets[kind] = set()
        for record in records:
            workflows[(str(record.get("platform")), str(record["analysis"].get("workflow_type")),
                       str(record.get("state")))] += 1
            if kind == "METHYLATION":
                platforms[methylation_platform(record.get("platform"))] += 1
            for case in record["cases"]:
                cid, name = case["case_id"], case["submitter_id"]
                require(cid not in case_names or case_names[cid] == name, "Case UUID/barcode inconsistency")
                require(name not in case_uuids or case_uuids[name] == cid, "Case barcode/UUID inconsistency")
                case_names[cid], case_uuids[name] = name, cid
                per_case[cid] += 1
                if kind != "METHYLATION" or methylation_platform(record.get("platform")) == "HM450":
                    case_sets[kind].add(cid)
                for sample in case["samples"]:
                    sid, sn = sample.get("sample_id"), sample.get("submitter_id")
                    if isinstance(sid, str) and sid:
                        require(sid not in sample_names or sample_names[sid] == (cid, sn),
                                "Sample UUID resolves to inconsistent case/barcode")
                        sample_names[sid] = (cid, sn)
            workflow_issues = target_workflow_issues(kind, record)
            file_link_rows, link_issues = file_links(kind, record)
            links_out.extend(file_link_rows)
            usable = not workflow_issues and not link_issues
            fixed_files += int(not workflow_issues)
            issues = sorted(set(workflow_issues + link_issues))
            issue_counts.update(issues)
            audits.append({"modality": kind, "file_id": record["file_id"],
                           "file_name": record["file_name"], "platform": record.get("platform"),
                           "workflow": record["analysis"].get("workflow_type"),
                           "fixed_workflow_eligible": not workflow_issues,
                           "unambiguous_primary_link": not link_issues,
                           "candidate_only_not_selected": usable, "issues": issues})
            if usable:
                link = next(x for x in file_link_rows if x["primary_tumor"])
                key = tuple(link[x] for x in ("case_id", "case_barcode", "sample_id",
                                              "sample_barcode", "portion_barcode"))
                groups.setdefault(key, {k: set() for k in KINDS})[kind].add(record["file_id"])
                case_kind_files[link["case_id"]][kind].add(record["file_id"])
        by_kind[kind] = {
            "open_file_count": len(records), "associated_case_count": len(per_case),
            "file_bytes_sum_not_downloaded": sum(r["file_size"] for r in records),
            "intended_workflow": TARGET_WORKFLOWS[kind],
            "fixed_workflow_metadata_eligible_file_count": fixed_files,
            "platform_workflow_file_counts": [
                {"platform": p, "workflow": w, "state": s, "files": n}
                for (p, w, s), n in sorted(workflows.items())],
            "methylation_platform_file_counts": dict(sorted(platforms.items())),
            "cases_with_multiple_files_count": sum(n > 1 for n in per_case.values()),
            "review_issue_counts": dict(sorted(issue_counts.items())),
        }
    candidates = []
    for key, kinds in sorted(groups.items()):
        if not all(kinds[k] for k in KINDS):
            continue
        unique_in_group = all(len(kinds[k]) == 1 for k in KINDS)
        unique_in_case = all(len(case_kind_files[key[0]][k]) == 1 for k in KINDS)
        candidates.append({
            **dict(zip(("case_id", "case_barcode", "sample_id", "sample_barcode", "portion_barcode"), key)),
            "RNA_file_ids": sorted(kinds["RNA"]),
            "METHYLATION_file_ids": sorted(kinds["METHYLATION"]),
            "CNV_file_ids": sorted(kinds["CNV"]),
            "unique_file_per_modality_in_group": unique_in_group,
            "unique_file_per_modality_across_case": unique_in_case,
            "status": "UNAMBIGUOUS_METADATA_CANDIDATE_NOT_SELECTED" if unique_in_group and unique_in_case
                      else "AMBIGUOUS_ALTERNATIVES_REVIEW_REQUIRED",
        })
    intersection = sorted(set.intersection(*(case_sets[k] for k in KINDS)))
    unambiguous = [x for x in candidates if x["status"].startswith("UNAMBIGUOUS_")]
    all_fixed_cases = set(case_kind_files)
    fixed_case_intersection = {cid for cid in all_fixed_cases
                              if all(case_kind_files[cid][k] for k in KINDS)}
    common_cases = {c["case_id"] for c in candidates}
    warnings = []
    if any(not all_records[k] for k in KINDS):
        warnings.append("Some requested data types have no open files; no substitute was chosen")
    if not case_sets["METHYLATION"]:
        warnings.append("No recognized HM450 files; HM27/other platforms are NOT substituted")
    if not unambiguous:
        warnings.append("No unambiguous same-sample+portion candidates; no training cohort declared")
    if any(c["status"].startswith("AMBIGUOUS_") for c in candidates):
        warnings.append("Some matched groups have alternative files; no arbitrary deduplication performed")
    mismatched_cases = sorted(fixed_case_intersection - common_cases)
    if mismatched_cases:
        warnings.append("Some fixed-workflow case overlaps lack the same sample UUID/portion barcode")
    report = {
        "status": "KIRC_METADATA_COLLECTION_COMPLETE_REQUIRES_REVIEW", "version": VERSION,
        "project": PROJECT, "created_at_utc": utc(), "by_modality": by_kind,
        "candidate_case_intersection_hm450_any_workflow_count": len(intersection),
        "candidate_case_intersection_hm450_any_workflow": [
            {"case_id": cid, "case_barcode": case_names[cid]} for cid in intersection],
        "fixed_workflow_primary_case_intersection_count": len(fixed_case_intersection),
        "same_sample_uuid_portion_barcode_candidate_group_count": len(candidates),
        "same_sample_uuid_portion_barcode_candidate_case_count": len(common_cases),
        "unambiguous_metadata_candidate_case_count": len({c["case_id"] for c in unambiguous}),
        "fixed_workflow_cases_without_same_sample_portion_group": [
            {"case_id": cid, "case_barcode": case_names[cid]} for cid in mismatched_cases],
        "final_training_sample_count": None, "final_cohort_selected": False,
        "warnings": warnings,
        "limitations": [
            "Availability by case is NOT final matched n; normal tissue availability is not tumor availability.",
            "File linkage is resolved from associated aliquot barcodes AND same-case sample metadata.",
            "Portion matching uses the barcode only, not an independently queried portion UUID.",
            "RNA and DNA aliquot identifiers need NOT match each other.",
            "Only released STAR-Counts / SeSAMe-HM450 / ASCAT3-SNP6 are candidate pathways; no fallback.",
            "All alternatives and linkage issues remain in the inventory; no data-driven file selection.",
            "No payload, header, feature, missingness, or cross-cohort sample-overlap audit performed.",
            "Paging checks cannot guarantee transactional snapshot isolation at the live GDC service.",
            "This post-SARC metadata snapshot is not a model protocol or historical preregistration.",
        ],
        "molecular_file_payloads_requested": False, "clinical_outcomes_requested": False,
        "project_code_imported": False, "project_results_read": False,
        "fit_or_metrics_run": False, "historical_files_modified": False,
        "analysis_authorization_created": False,
    }
    return report, {"links": links_out, "file_audit": audits, "candidates": candidates}


def bundle(run: Path, source: bytes) -> Path:
    """Compact evidence; raw API pages stay local and are hash-indexed, not duplicated."""
    write_new(run / "kirc0_source.py", source)
    checksums = []
    for path in sorted(run.iterdir()):
        require(path.is_file() and not path.is_symlink(), "Unexpected entry in fresh output directory")
        checksums.append({"name": path.name, **record_file(path)})
    write_json(run / "checksums.json", checksums)
    included = [p.name for p in sorted(run.iterdir()) if not p.name.endswith("_response.json")]
    write_json(run / "export_scope.json", {
        "included_files": included,
        "raw_api_pages": "kept locally; exact sizes and SHA256 listed in checksums.json",
        "all_completed_normalized_inventories_included": True,
        "molecular_payloads_included": False, "max_zip_bytes": MAX_EVIDENCE_BYTES,
    })
    included.append("export_scope.json")
    output = run.parent.parent / ("k0small_" + run.name.removeprefix("kirc_metadata_") + ".zip")
    # Refuse unusually large metadata before making the in-memory compact ZIP.
    require(sum((run / name).stat().st_size for name in included) <= 64 * 1024 * 1024,
            "Selected metadata exceeds 64 MiB; local reports preserved")
    # Memory buffer prevents publishing a too-large or incomplete final ZIP.
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in sorted(included):
            z.writestr(name, (run / name).read_bytes())
    blob = buf.getvalue()
    require(len(blob) <= MAX_EVIDENCE_BYTES,
            "Evidence exceeds 5 MiB: local reports preserved; do not archive molecular data")
    write_new(output, blob)
    return output


def main() -> int:
    print("TCGA-KIRC - metadata only; NOT a downloader, model runner or authorizer", flush=True)
    print("Version:", VERSION, flush=True)
    require(len(sys.argv) == 1, "No command-line options are accepted")
    source_path = Path(__file__).absolute()
    base = base_directory(source_path)
    source = source_path.read_bytes()
    destination = base / "metadata_runs"
    destination.mkdir(exist_ok=True)
    plain_directory(destination)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run = destination / ("kirc_metadata_" + stamp + "_" + uuid.uuid4().hex[:8])
    run.mkdir(exist_ok=False)
    write_json(run / "scope.json", {
        "version": VERSION, "project": PROJECT, "started_at_utc": utc(),
        "script_sha256": sha(source), "python_version": sys.version,
        "only_endpoint": ENDPOINT, "fields": FIELDS, "requested_types": KINDS,
        "candidate_workflows": TARGET_WORKFLOWS,
        "intended_methylation_platform": "HM450_ONLY_NO_HM27_FALLBACK",
        "existing_project_inputs_results_or_code_read": False,
        "molecular_download_or_training_authorized": False,
        "new_output_only": True,
        "source_context": "New KIRC metadata snapshot after the completed limited SARC application",
        "documentation": [
            "https://docs.gdc.cancer.gov/API/Users_Guide/Search_and_Retrieval/",
            "https://docs.gdc.cancer.gov/Encyclopedia/pages/TCGA_Barcode/",
            "https://docs.gdc.cancer.gov/Data/Bioinformatics_Pipelines/CNV_Pipeline/",
        ],
    })
    print("SARC/TARGET/simulation files: NOT READ; GPU/R/Torch/MOVE: NOT USED", flush=True)
    print("Only public GDC file/biospecimen metadata; HM450 and HM27 reported separately", flush=True)
    print("Intended CNV workflow: ASCAT3; alternatives inventoried, not substituted", flush=True)
    print("Output directory:", run, flush=True)
    exit_code = 0
    try:
        records = {kind: collect_type(kind, run) for kind in KINDS}
        report, details = make_summary(records)
        write_json(run / "sample_links.json", details["links"])
        write_json(run / "file_linkage_audit.json", details["file_audit"])
        write_json(run / "same_sample_portion_candidates_NOT_SELECTED.json", details["candidates"])
        write_new(run / "file_linkage_audit.csv", csv_bytes(details["file_audit"], [
            "modality", "file_id", "file_name", "platform", "workflow", "fixed_workflow_eligible",
            "unambiguous_primary_link", "candidate_only_not_selected", "issues"]))
        require(source_path.read_bytes() == source, "Source changed during collection")
    except (Exception, KeyboardInterrupt) as exc:
        exit_code = 1
        report = {"status": "KIRC_METADATA_COLLECTION_INCOMPLETE", "version": VERSION,
                  "project": PROJECT, "error_type": type(exc).__name__, "error": str(exc),
                  "final_training_sample_count": None, "final_cohort_selected": False,
                  "analysis_authorization_created": False, "molecular_file_payloads_requested": False,
                  "existing_project_files_modified": False,
                  "instruction": "Send the small evidence ZIP. Do not change SARC/TARGET/comparator files."}
    write_json(run / "report.json", report)
    output = bundle(run, source)
    print("Status:", report["status"], flush=True)
    if exit_code == 0:
        print("Candidate CASE intersection (HM450, any workflow; NOT final n):",
              report["candidate_case_intersection_hm450_any_workflow_count"], flush=True)
        print("Unambiguous same-sample/portion candidates (fixed workflows; NOT final n):",
              report["unambiguous_metadata_candidate_case_count"], flush=True)
        for warning in report["warnings"]:
            print("Review:", warning, flush=True)
    else:
        print("Error:", report["error_type"], report["error"], flush=True)
    print("Evidence ZIP (send this FILE, not its folder):", output, flush=True)
    print("Evidence ZIP bytes:", output.stat().st_size, flush=True)
    print("Evidence ZIP SHA-256:", sha(output.read_bytes()), flush=True)
    print("No acquisition or model authorization. Historical files not modified by this script.", flush=True)
    return exit_code


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print(f"KIRC METADATA STOPPED: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
