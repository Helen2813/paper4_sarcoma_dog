#!/usr/bin/env python3
"""Package small, existing SARC staging reports only. Python 3.10+, stdlib only.

Does not import sarc3, open matrices, rebuild data, fit models, change source
reports, or create analytical authorization. The large evidence ZIP is not read.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import stat
import sys
import uuid
import zipfile

VERSION = "sarc3-small-report-export-v1-no-matrices-no-rerun"
BASE_NAME = "paper5_parallel_sarc"
RUN_NAME = "sarc3_20261009T203157Z_0ca37523"
SOURCE_SHA = "344a84b6e7ac6961c9f9903ac145a21b7902c0660947c5f530121f98878c70eb"
STATUS = "RAW_MATRICES_STAGED_NOT_ANALYSIS_READY"
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_ZIP_BYTES = 5 * 1024 * 1024
SELECTED = (
    "report.json",
    "stage_complete.json",
    "stage_scope.json",
    "patients.tsv",
    "sample_bindings.tsv",
    "source_bindings.json",
    "row_fingerprints.json",
    "qc/methylation_identifier_review.json",
    "qc/methylation_non_cg_ids.tsv",
    "qc/duplicate_cnv_chromosome_review.json",
    "sarc3_source.py",
)


class ExportError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ExportError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")


def decode(data: bytes):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    def invalid(value):
        raise ExportError("Non-finite JSON token: " + value)
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs, parse_constant=invalid)


def plain(path: Path) -> None:
    for part in (path, *path.parents):
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        require(not stat.S_ISLNK(info.st_mode)
                and not (getattr(info, "st_file_attributes", 0) & 0x400),
                "Symlink/reparse point not allowed: " + str(part))


def read_small(path: Path) -> bytes:
    plain(path)
    require(path.is_file(), "Required report missing: " + str(path))
    before = path.stat()
    require(before.st_size <= MAX_FILE_BYTES, "Report exceeds export size limit: " + str(path))
    with path.open("rb") as handle:
        data = handle.read(MAX_FILE_BYTES + 1)
    after = path.stat()
    require(len(data) == before.st_size == after.st_size
            and before.st_mtime_ns == after.st_mtime_ns,
            "Report changed while reading: " + str(path))
    return data


def collect(stage: Path) -> tuple[dict[str, bytes], dict]:
    """Read the explicit report whitelist, not directory contents or matrix files."""
    payloads: dict[str, bytes] = {}
    total = 0
    for name in SELECTED:
        data = read_small(stage / name)
        total += len(data)
        require(total <= MAX_TOTAL_BYTES, "Selected reports exceed export size limit.")
        payloads[name] = data

    require(sha(payloads["sarc3_source.py"]) == SOURCE_SHA, "Saved sarc3 source SHA mismatch.")
    report = decode(payloads["report.json"])
    complete = decode(payloads["stage_complete.json"])
    for obj in (report, complete):
        require(obj.get("status") == STATUS, "Staging completion status differs.")
        require(obj.get("script_sha256") == SOURCE_SHA, "Staging source binding differs.")
    require(complete.get("model_authorization") is False, "Unexpected authorization state.")
    for key, expected in {
        "patients_staged": 250,
        "files_staged": 750,
        "numeric_matrix_count": 10,
        "row_fingerprints_replayed": 2500,
        "model_fits": 0,
        "source_and_prior_evidence_recheck": "PASS",
        "final_input_stat_recheck": "PASS",
    }.items():
        require(report.get(key) == expected, "Unexpected staging report field: " + key)
    require(report.get("clinical_outcomes_read") is False
            and report.get("authorization_created") is False,
            "Unexpected staging scope.")

    records = complete.get("files")
    require(isinstance(records, list), "Completion file manifest is missing.")
    indexed = {}
    for rec in records:
        require(isinstance(rec, dict) and isinstance(rec.get("path"), str), "Invalid completion record.")
        name = rec["path"]
        require(name not in indexed, "Repeated completion path: " + name)
        indexed[name] = rec
    for name, data in payloads.items():
        if name == "stage_complete.json":  # The completion manifest cannot hash itself.
            continue
        require(name in indexed, "Report not listed in completion manifest: " + name)
        rec = indexed[name]
        require(rec.get("size_bytes") == len(data) and rec.get("sha256") == sha(data)
                and rec.get("md5sum") == hashlib.md5(data).hexdigest(),
                "Report fingerprint mismatch: " + name)
    omitted = [rec for name, rec in sorted(indexed.items()) if name not in payloads]
    manifest = {
        "export_version": VERSION,
        "stage_run": stage.name,
        "status": "COMPACT_REPORT_COPY_NOT_ANALYSIS_AUTHORIZATION",
        "stage_complete_sha256": sha(payloads["stage_complete.json"]),
        "report_file_count": len(payloads),
        "selected_reports": [
            {"path": name, "size_bytes": len(data), "sha256": sha(data)}
            for name, data in payloads.items()
        ],
        "omitted_files_from_completion_manifest": omitted,
        "large_evidence_archive_read": False,
        "matrices_or_raw_molecular_files_read": False,
        "matrix_bytes_reverified_by_this_export": False,
        "source_reports_modified": False,
        "numerical_data_recomputed": False,
        "model_execution": False,
        "authorization_created": False,
        "verification_scope": "Selected reports checked against the local completion manifest; "
                              "original molecular files and matrices NOT rechecked by this exporter.",
    }
    return payloads, manifest


def make_zip(payloads: dict[str, bytes], manifest: dict) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in payloads.items():
            archive.writestr("stage/" + name, data)
        archive.writestr("compact_manifest.json", json_bytes(manifest))
    data = stream.getvalue()
    require(len(data) <= MAX_ZIP_BYTES,
            "Compact ZIP exceeds the 5 MiB export cap. No output was written.")
    # Check every member after compression, before publishing any file.
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        require(archive.testzip() is None, "Compact ZIP CRC verification failed.")
        for name, original in payloads.items():
            require(archive.read("stage/" + name) == original, "Copied report bytes differ: " + name)
    return data


def publish(path: Path, data: bytes) -> None:
    """Exclusive create: never overwrite a prior archive."""
    plain(path)
    with path.open("xb") as handle:
        handle.write(data)
    require(path.stat().st_size == len(data), "Output ZIP size differs; preserve it for inspection.")


def main() -> int:
    require(len(sys.argv) == 1, "No command-line arguments supported.")
    base = Path(__file__).absolute().parent
    require(base.name == BASE_NAME, "Place sarc3small.py inside paper5_parallel_sarc.")
    stage = base / "raw_staging_v1" / RUN_NAME
    print("SARC - compact copy of existing staging reports only", flush=True)
    print("Matrix rebuild / model execution: NO", flush=True)
    payloads, manifest = collect(stage)
    for name, data in payloads.items():
        require(read_small(stage / name) == data, "Report changed before packaging: " + name)
    data = make_zip(payloads, manifest)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = base / ("s3small_" + stamp + "_" + uuid.uuid4().hex[:8] + ".zip")
    publish(target, data)
    print("Selected reports and completion-manifest bindings: PASS", flush=True)
    print("Reports copied unchanged:", len(payloads), flush=True)
    print("Size: {:.2f} MiB ({} bytes)".format(len(data) / (1024 * 1024), len(data)), flush=True)
    print("Status: COMPACT_REPORT_COPY_NOT_ANALYSIS_AUTHORIZATION", flush=True)
    print("Upload this ZIP:", target, flush=True)
    print("ZIP SHA-256:", sha(data), flush=True)
    print("Original large ZIP, source reports and matrices: UNCHANGED", flush=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (Exception, KeyboardInterrupt) as exc:
        print("COMPACT EXPORT STOPPED:", type(exc).__name__, str(exc), flush=True)
        print("Do not rerun staging or edit its outputs. Send this error text.", flush=True)
        sys.exit(2)
