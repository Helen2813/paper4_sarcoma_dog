#!/usr/bin/env python3
"""SARC fixed pointwise input preparation, NOT training/selection authorization.

Reads three already staged matrices, writes new float32 pointwise inputs in a
separate immutable run directory. All patients retained. Only a STATIC cg-ID
filter is applied. No feature ranking, imputation, standardization, PCA, batch
correction, model fitting, clinical/outcome access or network requests.
Python 3.10+ and NumPy; no project module is imported.
"""
from __future__ import annotations
import collections
import contextlib
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import traceback
import uuid
import zipfile
for _key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_key] = "1"
import numpy as np

VERSION = "sarc4-fixed-pointwise-inputs-cg-only-fold-local-boundary-v1-no-fit"
BASE_NAME = "paper5_parallel_sarc"
STAGE_RUN = "sarc3_20261009T203157Z_0ca37523"
COMPLETE_SHA = "0cff3e068a8a55367f2e74cf7eaa7f0729a52d350db3c554c644e6030e0e2af7"
SARC3_SHA = "344a84b6e7ac6961c9f9903ac145a21b7902c0660947c5f530121f98878c70eb"
N = 250
EPS = np.float32(1e-6)
VIEWS = ("RNA", "METHYLATION", "CNV")
SPECS = {
    "RNA": {"input": "matrices/RNA__tpm_unstranded.npy", "width": 60660, "out_width": 60660, "output": "RNA_log2tpm.npy"},
    "METHYLATION": {"input": "matrices/METHYLATION__beta_value.npy", "width": 486427, "out_width": 482421, "output": "METHYLATION_Mvalue.npy"},
    "CNV": {"input": "matrices/CNV__copy_number.npy", "width": 60623, "out_width": 60623, "output": "CNV_log2ratio.npy"},
}
SMALL_STAGE = ("report.json", "stage_scope.json", "patients.tsv", "sample_bindings.tsv", "source_bindings.json", "row_fingerprints.json", "qc/methylation_identifier_review.json", "qc/methylation_non_cg_ids.tsv", "qc/duplicate_cnv_chromosome_review.json", "sarc3_source.py")
STATUS = "POINTWISE_INPUTS_COMPLETE_NOT_MODEL_AUTHORIZED"
CG = re.compile(r"cg\d+\Z")

class PreparationError(RuntimeError):
    pass

def need(ok: bool, message: str) -> None:
    if not ok:
        raise PreparationError(message)

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def encode(obj: object) -> bytes:
    return (json.dumps(obj, ensure_ascii=True, allow_nan=False, sort_keys=True, indent=2) + "\n").encode()

def decode(data: bytes):
    def pairs(items):
        d = {}
        for k, v in items:
            need(k not in d, "Duplicate JSON key: " + k)
            d[k] = v
        return d
    def bad(value):
        raise PreparationError("Non-finite JSON constant: " + value)
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs, parse_constant=bad)

def plain(path: Path) -> None:
    for p in (path, *path.parents):
        try: s = p.lstat()
        except FileNotFoundError: continue
        need(not stat.S_ISLNK(s.st_mode) and not (getattr(s, "st_file_attributes", 0) & 0x400), "Symlink/reparse point: " + str(p))

def relative(root: Path, name: str) -> Path:
    need(isinstance(name, str) and "\\" not in name and ":" not in name, "Unsafe relative path")
    p = PurePosixPath(name)
    need(not p.is_absolute() and bool(p.parts) and all(x not in (".", "..") for x in p.parts) and p.as_posix() == name, "Noncanonical path")
    path = root.joinpath(*p.parts); plain(path)
    return path

def small(path: Path, limit: int = 32 * 1024 * 1024) -> bytes:
    plain(path); need(path.is_file(), "Required file missing: " + str(path))
    s = path.stat(); need(s.st_size <= limit, "File too large for small read: " + str(path))
    with path.open("rb") as f: b = f.read(limit + 1)
    t = path.stat()
    need(len(b) == s.st_size == t.st_size and s.st_mtime_ns == t.st_mtime_ns, "File changed while reading: " + str(path))
    return b

def fingerprint(path: Path) -> dict:
    plain(path); need(path.is_file(), "Required file missing: " + str(path))
    s = path.stat(); h, m, n = hashlib.sha256(), hashlib.md5(), 0
    with path.open("rb") as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(b); m.update(b); n += len(b)
    t = path.stat()
    need(n == s.st_size == t.st_size and s.st_mtime_ns == t.st_mtime_ns, "File changed during hashing: " + str(path))
    return {"sha256": h.hexdigest(), "md5sum": m.hexdigest(), "size_bytes": n}

def matches(got: dict, expected: dict, label: str) -> None:
    need(all(got[k] == expected[k] for k in ("size_bytes", "sha256", "md5sum")), "Fingerprint mismatch: " + label)

def create(path: Path, data: bytes) -> None:
    plain(path)
    with path.open("xb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())

def tsv(path: Path, header, rows) -> None:
    plain(path)
    with path.open("x", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t", lineterminator="\n"); w.writerow(header); w.writerows(rows)
        f.flush(); os.fsync(f.fileno())

def canonical_row_hash(x: np.ndarray, dtype: str) -> str:
    y = np.array(x, dtype=dtype, order="C", copy=True)
    y[np.isnan(y)] = np.nan
    return sha(y.tobytes())

def close_map(x, write: bool = False) -> None:
    if x is not None:
        if write: x.flush()
        x._mmap.close()

@contextlib.contextmanager
def exclusive_lock(path: Path):
    plain(path); f = path.open("a+b"); locked = False
    try:
        if os.name == "nt":
            import msvcrt
            if path.stat().st_size == 0: f.write(b"0"); f.flush()
            f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locked = True
        yield
    finally:
        if locked:
            if os.name == "nt":
                import msvcrt
                f.seek(0); msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(f, fcntl.LOCK_UN)
        f.close()

def load_snapshot(stage: Path, expected_sha: str = COMPLETE_SHA, n: int = N, specs: dict | None = None) -> dict:
    specs = SPECS if specs is None else specs
    complete_bytes = small(stage / "stage_complete.json")
    need(sha(complete_bytes) == expected_sha, "Pinned sarc3 completion SHA mismatch")
    complete = decode(complete_bytes)
    need(complete["status"] == "RAW_MATRICES_STAGED_NOT_ANALYSIS_READY" and complete["model_authorization"] is False, "Invalid raw staging status")
    records = {r["path"]: r for r in complete["files"]}
    need(len(records) == len(complete["files"]), "Duplicate completion paths")
    blobs = {"stage_complete.json": complete_bytes}
    for name in SMALL_STAGE:
        b = small(relative(stage, name)); rec = records[name]
        matches({"size_bytes": len(b), "sha256": sha(b), "md5sum": hashlib.md5(b).hexdigest()}, rec, name)
        blobs[name] = b
    report = decode(blobs["report.json"])
    need(report["status"] == complete["status"] and report["patients_staged"] == n and report["files_staged"] == n * 3, "Staging report population mismatch")
    need(report["model_fits"] == 0 and report["clinical_outcomes_read"] is False and report["authorization_created"] is False, "Unexpected prior execution scope")
    need(report["script_sha256"] == complete["script_sha256"] == sha(blobs["sarc3_source.py"]) == SARC3_SHA, "Staging source mismatch")
    patient_rows = list(csv.DictReader(io.StringIO(blobs["patients.tsv"].decode("utf-8-sig")), delimiter="\t"))
    patients = [r["case_submitter_id"] for r in patient_rows]
    need(len(patients) == len(set(patients)) == n and patients == sorted(patients), "Invalid case order")
    need([int(r["row_index"]) for r in patient_rows] == list(range(n)), "Invalid patient row indices")
    bindings = decode(blobs["source_bindings.json"])
    source_map = {(r["row_index"], r["modality"]): r for r in bindings}
    need(len(source_map) == len(bindings) == n * 3, "Duplicate or missing case/view bindings")
    for i, case in enumerate(patients):
        rr = [source_map[(i, view)] for view in VIEWS]
        need(all(r["case_submitter_id"] == case and r["sample_type"] == "Primary Tumor" for r in rr), "Case/sample type mismatch")
        need(all(len({r[k] for r in rr}) == 1 for k in ("case_id", "sample_id", "sample_submitter_id", "portion_barcode")), "Unmatched tumor samples")
    row_records = decode(blobs["row_fingerprints.json"])
    row_map = {(r["matrix"], r["row_index"]): r for r in row_records}
    need(len(row_map) == len(row_records) == n * 10, "Incomplete/duplicate raw matrix fingerprints")
    for view in VIEWS:
        name = specs[view]["input"]
        for i, case in enumerate(patients):
            r = row_map[(Path(name).name, i)]
            need(r["case_submitter_id"] == case and r["source_file_id"] == source_map[(i, view)]["file_id"], "Row/source identity mismatch")
        need(report["features"][view]["rows"] == specs[view]["width"], "Feature count mismatch: " + view)
    return {"records": records, "blobs": blobs, "patients": patients, "rows": row_map, "report": report, "stage_complete_sha256": expected_sha}

def read_features(stage: Path, view: str, snapshot: dict, spec: dict) -> dict:
    name = view + ".features.tsv"; path = stage / name
    matches(fingerprint(path), snapshot["records"][name], name)
    rows = csv.reader(io.StringIO(small(path).decode("utf-8-sig")), delimiter="\t")
    header = next(rows)
    identity = "probe_id" if view == "METHYLATION" else "gene_id"
    need(header[0] == "feature_index" and header[1] == identity, "Unexpected feature header: " + view)
    annotations = []
    for i, r in enumerate(rows):
        need(len(r) == len(header) and int(r[0]) == i, "Feature row schema/order mismatch")
        annotations.append(tuple(r[1:]))
    ids = [r[0] for r in annotations]
    need(len(ids) == len(set(ids)) == spec["width"], "Invalid feature count or duplicate ID")
    h = hashlib.sha256()
    for s in ids: h.update(s.encode()); h.update(b"\0")
    need(h.hexdigest() == snapshot["report"]["features"][view]["order_sha256"], "Feature order fingerprint mismatch")
    keep = np.asarray([i for i, s in enumerate(ids) if view != "METHYLATION" or CG.fullmatch(s)], dtype=np.int64)
    need(len(keep) == spec["out_width"], "Static feature policy count mismatch")
    if view == "METHYLATION":
        observed = collections.Counter("cg" if CG.fullmatch(s) else "ch" if s.startswith("ch.") else "rs" if re.fullmatch(r"rs\d+", s) else "ctl" if re.fullmatch(r"ctl_\d+", s) else "unknown" for s in ids)
        need(observed["unknown"] == 0, "Unexpected new methylation identifier class")
        review = decode(snapshot["blobs"]["qc/methylation_identifier_review.json"])
        old = review["lexical_class_counts"]
        need(dict(observed) == {"cg": old["cg"], "ch": old["ch"], "rs": old["rs"], "ctl": old["other"]}, "Probe class inventory mismatch")
    return {"header": header[1:], "annotations": annotations, "ids": ids, "keep": keep}

def transform_row(raw: np.ndarray, view: str) -> np.ndarray:
    """Pointwise only. No statistics of other rows enter this function."""
    raw = np.asarray(raw, dtype=np.float64)
    need(raw.ndim == 1 and not np.isinf(raw).any(), "Invalid raw numeric row")
    mask = np.isfinite(raw)
    need(not np.any(raw[mask] < 0), "Negative input before transform: " + view)
    if view == "RNA":
        # log is evaluated before float32 export, as for decimal TPM inputs.
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            out = np.log2(raw + 1.0).astype("<f4")
    else:
        need(view in ("CNV", "METHYLATION"), "Unknown view")
        if view == "METHYLATION": need(not np.any(raw[mask] > 1), "Beta value above one")
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            values = raw.astype(np.float32)
            if view == "METHYLATION":
                b = np.clip(values, EPS, np.float32(1.0) - EPS)
                out = np.log2(b / (np.float32(1.0) - b)).astype("<f4")
            else:
                out = np.log2(np.clip(values, EPS, None) / np.float32(2.0)).astype("<f4")
    need(np.array_equal(np.isnan(out), np.isnan(raw)) and np.isfinite(out[mask]).all(), "Nonfinite transform or changed missingness")
    return out

def input_plan() -> dict:
    return {
        "version": VERSION, "stage_run": STAGE_RUN, "source_complete_sha256": COMPLETE_SHA,
        "patient_rule": "retain all 250 metadata-selected primary-tumor cases in existing order; no QC-based case rescue/exclusion",
        "input_channels": {"RNA": "tpm_unstranded", "METHYLATION": "beta_value", "CNV": "copy_number (ASCAT3, not min/max)"},
        "pointwise_transforms": {"RNA": "float32(log2(float64(TPM)+1))", "METHYLATION": "values=float32(beta); b=clip(values,float32(1e-6),float32(1)-float32(1e-6)); float32(log2(b/(float32(1)-b)))", "CNV": "float32(log2(clip(float32(CN),float32(1e-6),None)/float32(2)))"},
        "static_feature_rules": {"RNA": "all exact gene IDs, no collapsing by symbol", "METHYLATION": "exact cg[0-9]+ IDs only; retain source-index mapping; non-cg raw staging preserved", "CNV": "all exact gene IDs and all chromosomes retained at this step"},
        "missingness": "NaN retained at original locations in included features; finite zero is not missing",
        "quantization": "new derived inputs stored float32; original staged float64 inputs untouched; not a claim of end-to-end bitwise TARGET equivalence",
        "population_dependent_operations": "missingness filtering, zero-variance filtering, variance ranking, imputation, centering/scaling and PCA must be fitted using training rows only inside each future split/resample",
        "this_stage_does_not": ["select models", "create CV splits", "fit PCA or neural models", "select variance-ranked features globally", "impute", "standardize", "infer sex or duplicate patients", "read outcomes/clinical labels", "change any historical benchmark"],
        "duplicate_CNV_policy": "record observed identical input rows; do not infer duplicate patients and do not delete/replace them",
        "biological_annotation_claim": "ctl_ class is lexical in input files; no individual probe genomic annotation inferred",
        "old_script_metadata_copy": "optional allowlisted code/configuration bytes copied for next-stage review; not imported/executed or claimed historically verified",
        "analytical_model_protocol": "pending separate definition and synthetic implementation tests; this preparation is not model authorization",
    }

def copy_reference_sources(project: Path, out: Path) -> tuple[dict, dict]:
    """Collect bounded known code/config files, never model/data directories."""
    candidates = set()
    for pattern in ("04c_prestandardization*.py", "06b_run_target_outcome_blind_representation_benchmark*.py", "06c_run_target*refit*.py"):
        candidates.update((project / "paper5/scripts").glob(pattern))
    fixed = [
        "paper5/model_inputs/TARGET_OS_primary78/premodel_qc/fold_local_preprocessing_contract.json",
        "paper5/model_inputs/TARGET_OS_primary78/premodel_qc/representation_feature_budget_plan.csv",
        "paper5/method_contract/05a/ai_method_contract.json", "paper5/method_contract/05a/model_family_registry.csv",
        "paper5/method_contract/05a/baseline_hyperparameter_grid.csv", "paper5/method_contract/05a/model_selection_policy.json",
        "paper5/method_contract/06a/target_application_contract.json", "paper5/method_contract/06a/06a_contract_lock.json",
        "paper5/method_contract/06b/target_outcome_blind_benchmark_results_lock.json",
    ]
    candidates.update(project / n for n in fixed)
    records = []; originals = {}; total = 0
    for p in sorted(candidates):
        rel = p.relative_to(project).as_posix(); plain(p)
        if not p.is_file(): records.append({"path": rel, "status": "NOT_PRESENT"}); continue
        size = p.stat().st_size
        if size > 2 * 1024 * 1024 or total + size > 8 * 1024 * 1024:
            records.append({"path": rel, "status": "NOT_COPIED_SIZE_LIMIT", "size_bytes": size}); continue
        b = small(p, 2 * 1024 * 1024); dest = relative(out / "reference_sources", rel)
        dest.parent.mkdir(parents=True, exist_ok=True); create(dest, b)
        total += len(b); originals[p] = sha(b)
        records.append({"path": rel, "status": "COPIED_BYTES_ONLY_NOT_EXECUTED", "size_bytes": len(b), "sha256": sha(b)})
    pack = {"scope": "code and configuration only; historical links not verified by this copy", "records": records, "copied_total_bytes": total}
    create(out / "reference_sources.json", encode(pack))
    return pack, originals

def prepare_one(stage: Path, out: Path, view: str, snapshot: dict, spec: dict) -> dict:
    infile = relative(stage, spec["input"])
    matches(fingerprint(infile), snapshot["records"][spec["input"]], spec["input"])
    f = read_features(stage, view, snapshot, spec); keep = f["keep"]; n = len(snapshot["patients"])
    outfile = out / "matrices" / spec["output"]
    create(outfile, b"")
    x = y = None; summaries = []; missing = np.zeros(len(keep), dtype=np.int64); row_hashes = []
    rawname = Path(spec["input"]).name
    try:
        x = np.load(infile, mmap_mode="r", allow_pickle=False)
        need(x.shape == (n, spec["width"]) and x.dtype == np.dtype("<f8") and x.flags.c_contiguous, "Raw matrix shape/dtype/order mismatch: " + view)
        y = np.lib.format.open_memmap(outfile, mode="w+", dtype="<f4", shape=(n, len(keep)), fortran_order=False, version=(2, 0))
        for i, case in enumerate(snapshot["patients"]):
            need(canonical_row_hash(x[i], "<f8") == snapshot["rows"][(rawname, i)]["row_sha256"], "Raw row fingerprint mismatch: " + view + "/" + case)
            raw = np.asarray(x[i, keep], dtype=np.float64); z = transform_row(raw, view); y[i] = z
            mask = np.isfinite(raw); missing += (~mask).astype(np.int64)
            low = high = 0
            if view != "RNA":
                vf = raw[mask].astype(np.float32); low = int((vf < EPS).sum())
                if view == "METHYLATION": high = int((vf > np.float32(1) - EPS).sum())
            digest = canonical_row_hash(z, "<f4"); row_hashes.append(digest)
            summaries.append({"view": view, "case_submitter_id": case, "row_index": i, "n_features": len(z), "missing_count": int((~mask).sum()), "finite_zero_count_before_transform": int((raw[mask] == 0).sum()), "clipped_low_count": low, "clipped_high_count": high, "finite_min": float(z[mask].min()) if mask.any() else None, "finite_max": float(z[mask].max()) if mask.any() else None, "constant_among_finite": bool(mask.any() and z[mask].min() == z[mask].max()), "row_sha256": digest})
            if i == 0 or (i + 1) % 50 == 0: print(f"{view}: {i+1}/{n} raw-row/transform/write PASS", flush=True)
        close_map(y, True); y = None
        y = np.load(outfile, mmap_mode="r", allow_pickle=False)
        need(y.shape == (n, len(keep)) and y.dtype == np.dtype("<f4"), "Output matrix geometry mismatch")
        for i in range(n):
            expected = transform_row(x[i, keep], view)
            need(canonical_row_hash(y[i], "<f4") == row_hashes[i] and np.array_equal(y[i], expected, equal_nan=True), "Stored transformed row differs on replay")
    finally:
        close_map(y); close_map(x)
    matches(fingerprint(infile), snapshot["records"][spec["input"]], "unchanged raw " + view)
    matches(fingerprint(stage / (view + ".features.tsv")), snapshot["records"][view + ".features.tsv"], "unchanged features " + view)
    tsv(out / (view + ".features.tsv"), ["feature_index", "source_feature_index", *f["header"]], ((j, int(i), *f["annotations"][i]) for j, i in enumerate(keep)))
    tsv(out / "qc" / (view + "_feature_missing_counts.tsv"), ["feature_index", "source_feature_index", "feature_id", "missing_n"], ((j, int(i), f["ids"][i], int(missing[j])) for j, i in enumerate(keep)))
    create(out / "qc" / (view + "_row_qc.json"), encode(summaries))
    group = collections.defaultdict(list)
    for r in summaries: group[r["row_sha256"]].append(r["case_submitter_id"])
    # This scan is descriptive. No exclusions are made using these quantities.
    return {"view": view, "path": "matrices/" + spec["output"], "shape": [n, len(keep)], "dtype": "<f4", **fingerprint(outfile), "source_path": spec["input"], "source_sha256": snapshot["records"][spec["input"]]["sha256"], "raw_rows_verified": n, "transformed_rows_replayed": n, "features_removed_by_static_class": spec["width"] - len(keep), "patients_removed": 0, "all_missing_features_retained_for_fold_local_filter": int((missing == n).sum()), "total_missing": int(missing.sum()), "clipped_low_count": sum(r["clipped_low_count"] for r in summaries), "clipped_high_count": sum(r["clipped_high_count"] for r in summaries), "constant_among_finite_cases": [r["case_submitter_id"] for r in summaries if r["constant_among_finite"]], "identical_transformed_row_groups": [g for g in group.values() if len(g) > 1]}

def export_evidence(base: Path, out: Path) -> Path:
    # Explicit report whitelist. Never add entire output directories or matrices.
    names = ["report.json", "input_plan.json", "sarc4_source.py", "patients.tsv", "reference_sources.json", "input_complete.json", "failure.json", "traceback.txt", "qc/retained_cnv_input_flags.json"]
    names += ["qc/" + v + "_row_qc.json" for v in VIEWS]
    files = [(name, out / name) for name in names if (out / name).is_file()]
    for d in ("reference_sources", "prior_stage_reports"):
        if (out / d).is_dir():
            files += [(p.relative_to(out).as_posix(), p) for p in sorted((out / d).rglob("*")) if p.is_file()]
    blobs = {name: small(p) for name, p in files}
    need(sum(map(len, blobs.values())) <= 16 * 1024 * 1024, "Evidence uncompressed size limit exceeded")
    blobs["evidence_manifest.json"] = encode({"files": [{"path": n, "size_bytes": len(b), "sha256": sha(b)} for n, b in sorted(blobs.items())], "matrices_included": False, "full_feature_tables_included": False, "model_authorization": False})
    path = base / ("s4small_" + out.name.removeprefix("sarc4_") + ".zip")
    with zipfile.ZipFile(path, "x", zipfile.ZIP_DEFLATED) as z:
        for name, b in sorted(blobs.items()): z.writestr(name, b)
    need(path.stat().st_size <= 5 * 1024 * 1024, "Evidence ZIP over 5 MiB; do not send a full matrix folder")
    return path

def main() -> int:
    script = Path(__file__).absolute(); plain(script); base = script.parent
    need(base.name == BASE_NAME and len(sys.argv) == 1, "Place sarc4.py in paper5_parallel_sarc; no CLI arguments")
    source = small(script); stage = base / "raw_staging_v1" / STAGE_RUN; plain(stage)
    print("TCGA-SARC - fixed pointwise inputs; NO fitting or model authorization", flush=True)
    print("Version:", VERSION, flush=True)
    print("Three raw matrices read; clinical/outcomes/network/GPU/R: NOT USED", flush=True)
    out = None; code = 0
    report = {"version": VERSION, "script_sha256": sha(source), "started_at_utc": now(), "python": sys.version, "numpy": np.__version__, "model_fits": 0, "clinical_outcomes_read": False, "model_authorization": False, "existing_files_modified": False, "network_used": False}
    try:
        with exclusive_lock(base / ".sarc4_inputs.lock"):
            snap = load_snapshot(stage)
            print("Pinned completed sarc3 / patient and source-row bindings: PASS", flush=True)
            need(shutil.disk_usage(base).free > sum(N * SPECS[v]["out_width"] * 4 for v in VIEWS) + 512 * 1024 * 1024, "Insufficient free disk space")
            parent = base / "pointwise_inputs_v1"; plain(parent); parent.mkdir(exist_ok=True)
            out = parent / (datetime.now(timezone.utc).strftime("sarc4_%Y%m%dT%H%M%SZ_") + uuid.uuid4().hex[:8]); out.mkdir()
            (out / "matrices").mkdir(); (out / "qc").mkdir(); (out / "prior_stage_reports").mkdir()
            print("Output directory:", out, flush=True)
            create(out / "sarc4_source.py", source)
            # Publish the fixed preparation scope before matrix payload access.
            create(out / "input_plan.json", encode(input_plan()))
            create(out / "patients.tsv", snap["blobs"]["patients.tsv"])
            for name in ("stage_complete.json", "report.json", "qc/methylation_identifier_review.json", "qc/duplicate_cnv_chromosome_review.json"):
                dest = out / "prior_stage_reports" / name; dest.parent.mkdir(parents=True, exist_ok=True); create(dest, snap["blobs"][name])
            grouped = collections.defaultdict(list)
            for r in snap["rows"].values():
                if r["matrix"] == "CNV__copy_number.npy": grouped[r["row_sha256"]].append(r["case_submitter_id"])
            create(out / "qc/retained_cnv_input_flags.json", encode({"identical_raw_copy_number_row_groups": [g for g in grouped.values() if len(g) > 1], "patient_exclusions": [], "not_evidence_of_same_patient": True}))
            refs, originals = copy_reference_sources(base.parent, out)
            matrices = [prepare_one(stage, out, v, snap, SPECS[v]) for v in VIEWS]
            for name, b in snap["blobs"].items(): need(small(relative(stage, name)) == b, "Prior report changed: " + name)
            for p, h in originals.items(): need(sha(small(p)) == h, "Reference source/config changed: " + str(p))
            need(small(script) == source, "sarc4 source changed during execution")
            report.update({"status": STATUS, "finished_at_utc": now(), "patients": N, "patient_exclusions": [], "matrices": matrices, "raw_matrix_hash_checks_before_after": 6, "raw_rows_verified": N * 3, "transformed_rows_replayed": N * 3, "source_stage_complete_sha256": COMPLETE_SHA, "imputation": False, "scaling": False, "PCA": False, "variance_ranking": False, "static_cg_filter_applied": True, "reference_files_copied": sum(r["status"] == "COPIED_BYTES_ONLY_NOT_EXECUTED" for r in refs["records"]), "next_step": "review fixed scale inputs and existing TARGET implementation; define limited SARC evaluation and test synthetic runner before fitting"})
            create(out / "report.json", encode(report))
            records = [{"path": p.relative_to(out).as_posix(), **fingerprint(p)} for p in sorted(out.rglob("*")) if p.is_file()]
            create(out / "input_complete.json", encode({"status": STATUS, "script_sha256": sha(source), "source_stage_complete_sha256": COMPLETE_SHA, "files": records, "model_authorization": False}))
            print("All 750 transformed rows reopened and formula-replayed: PASS", flush=True)
    except (Exception, KeyboardInterrupt) as exc:
        code = 2; report.update({"status": "POINTWISE_PREPARATION_INCOMPLETE", "error_type": type(exc).__name__, "error": str(exc), "finished_at_utc": now()})
        if out is not None:
            create(out / "failure.json", encode(report)); create(out / "traceback.txt", traceback.format_exc().encode())
        print("PREPARATION STOPPED:", type(exc).__name__, str(exc), flush=True)
    if out is not None:
        try:
            evidence = export_evidence(base, out)
            print("Status:", report["status"], flush=True)
            print("Evidence ZIP (send this FILE):", evidence, flush=True)
            print("Evidence ZIP bytes:", evidence.stat().st_size, flush=True)
            print("Evidence ZIP SHA-256:", fingerprint(evidence)["sha256"], flush=True)
        except Exception as exc:
            code = 2; print("Compact export stopped; preserve output directory:", out, repr(exc), flush=True)
    print("Historical scripts/data/results untouched. No model run or authorization.", flush=True)
    return code

if __name__ == "__main__":
    try: sys.exit(main())
    except (Exception, KeyboardInterrupt) as exc:
        print("PREPARATION STOPPED:", type(exc).__name__, str(exc), flush=True); sys.exit(2)
