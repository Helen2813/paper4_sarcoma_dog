from __future__ import annotations

"""Freeze a LIMITED SARC protocol and exercise its model path on ARTIFICIAL data.

Zero command-line options. This entry point CANNOT fit the real SARC cohort.
The reusable helpers below are the candidate numerical implementation for a later,
separately source-authorized external runner. No historical script/lock is edited.
"""

import contextlib
import csv
import gc
import hashlib
import importlib.util
import json
import math
import os
import platform
import sys
import tempfile
import time
import traceback
import uuid
import warnings
import zipfile
from dataclasses import asdict, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
for _name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_name] = '2'

import numpy as np
import pandas as pd

VERSION = 'sarc5-limited-external-protocol-and-synthetic-model-path-v1-no-real-fit'
VIEWS = ('RNA', 'METHYLATION', 'CNV')
MODELS = ('BLOCK_PCA_BUDGETED_K10', 'V1_SHARED_PRIVATE_AE', 'V4_SABLE_MO')
NEURAL_MODELS = MODELS[1:]
SEEDS = (1103, 2207)
BUDGETS = {'RNA': 5000, 'METHYLATION': 10000, 'CNV': 5000}
PC_RANKS = {v: 10 for v in VIEWS}
SOURCE_PINS = {
    'paper5/scripts/06b_run_target_outcome_blind_representation_benchmark_gpu_v4.py':
        '4f69680a2d26d6c8e4bd5b337a5e94e6cdc36d149ea6a4b9af547b3855a93eab',
    'paper5/scripts/05d2v2_screen_neural_profiles_gpu_syncfree_pathfix.py':
        '05ae6923ce588c137bc6f4aa934262181dd99f4ebe6bec3250e4b7cd54ed1ff3',
    'paper5/scripts/05d4_fit_neural_ablation_benchmark_gpu_v1_2_verified.py':
        '8ab3b84f1d7bcd475b88b5f06d49e661c2d6230ea3598406e66970d792c74a5c',
    'paper5/method_contract/05d1/neural_architecture_regularization_profile_grid.csv':
        '118b2fd4c16751f0b83ac3053f726f9421db26949ab98a8a531ff584c194ee32',
    'paper5/method_contract/05d1/neural_loss_and_architecture_contract.json':
        'b90ded1d011ee3210154c2102389df0b4e0c8fcf668b70d7e2b8e14184e3f6b1',
}
INPUT_RUN = 'sarc4_20261010T015241Z_dbf619ed'
INPUT_COMPLETE_SHA = '81a0c365e9b7d62af957161350f7fabc4de700785285aab16d8436d89e863265'
PATIENT_SHA = 'e279425a714649c30a409d091fd9c819b86e2912784e9413a53e21d7ccfdde3f'
INPUT_MATRICES = {
    'RNA': ('matrices/RNA_log2tpm.npy', '1d02f9af9c529858546fe38f8283560fd5ec49d54311460ce5acf83bfcfd6c71', 60660),
    'METHYLATION': ('matrices/METHYLATION_Mvalue.npy', '07dffebcf534829eec833749c65b8f679d0c0246702bb884e817b8727e18b9c3', 482421),
    'CNV': ('matrices/CNV_log2ratio.npy', 'b51893efc3bb03564658bcdb67f4025d48d9d5ddf9fb0e94116bf5be644a6395', 60623),
}
SYNTHETIC_EPOCHS = 2
MAX_EVIDENCE_BYTES = 5 * 1024 * 1024


def need(ok: Any, message: str) -> None:
    if not bool(ok):
        raise RuntimeError(message)


def sha_file(path: Path) -> str:
    need(path.is_file() and not path.is_symlink(), 'Required regular file missing: ' + str(path))
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, ensure_ascii=True, allow_nan=False, indent=2) + '\n').encode()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


def write_or_verify(path: Path, data: bytes) -> None:
    if path.exists():
        need(path.read_bytes() == data, 'Existing protocol differs; do not overwrite: ' + str(path))
    else:
        write_new(path, data)


@contextlib.contextmanager
def process_lock(path: Path):
    # OS lock is released on exit, including a killed process. The small file stays.
    path.parent.mkdir(parents=True, exist_ok=True)
    f = path.open('a+b')
    f.seek(0, 2)
    if f.tell() == 0:
        f.write(b'0'); f.flush()
    f.seek(0)
    try:
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as exc:
        f.close()
        raise RuntimeError('Another sarc5 process holds the lock; do not delete it.') from exc
    try:
        yield
    finally:
        f.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        f.close()


def import_exact(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'Cannot create source spec: ' + str(path))
    module = importlib.util.module_from_spec(spec)
    prior = sys.modules.get(name)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        if prior is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = prior
        raise
    return module


def verify_sources(project: Path) -> dict[str, str]:
    result = {}
    for rel, expected in SOURCE_PINS.items():
        observed = sha_file(project / rel)
        need(observed == expected, 'Source SHA mismatch: ' + rel)
        result[rel] = observed
    return result


def load_runtime(project: Path) -> dict[str, Any]:
    verify_sources(project)
    names = list(SOURCE_PINS)
    target = import_exact(project / names[0], 'sarc5_exact_06b_v4')
    neural = import_exact(project / names[1], 'sarc5_exact_05d2')
    ablation = import_exact(project / names[2], 'sarc5_exact_05d4')
    table = pd.read_csv(project / names[3], dtype=str).fillna('')
    rows = table.loc[table['profile_id'].eq('ARCH_COMPACT__REG_WEAK')]
    need(len(rows) == 1, 'Expected exactly one fixed compact/weak profile.')
    profile = neural.parse_profile(rows.iloc[0])
    need(profile.shared_dim == 5 and profile.private_dim == 2 and profile.hidden_dim == 32,
         'Unexpected fixed neural geometry.')
    need(profile.maximum_epochs == 400 and profile.patience == 30 and profile.pca_components == PC_RANKS,
         'Unexpected fixed training schedule/PCA geometry.')
    variants = ablation.build_variant_specs(load_json(project / names[4]))
    need(target.FEATURE_BUDGETS == BUDGETS and target.NEURAL_PCA_COMPONENTS == PC_RANKS,
         'TARGET feature budgets or PCA dimensions differ.')
    need(target.MAXIMUM_MISSING_FRACTION == {'RNA': 0.0, 'METHYLATION': 0.20, 'CNV': 0.0},
         'Unexpected source feature-missingness policy.')
    for key in NEURAL_MODELS:
        need(key in variants and not variants[key].variational_latent, 'Unexpected variant: ' + key)
    return {'target': target, 'neural': neural, 'ablation': ablation,
            'profile': profile, 'variants': variants, 'profile_grid_row': rows.iloc[0].to_dict()}


def verify_input_metadata(parallel: Path) -> tuple[Path, list[str], dict[str, Any]]:
    root = parallel / 'pointwise_inputs_v1' / INPUT_RUN
    need(sha_file(root / 'input_complete.json') == INPUT_COMPLETE_SHA, 'sarc4 completion SHA differs.')
    c = load_json(root / 'input_complete.json')
    need(c['status'] == 'POINTWISE_INPUTS_COMPLETE_NOT_MODEL_AUTHORIZED', 'sarc4 is not complete.')
    need(sha_file(root / 'patients.tsv') == PATIENT_SHA, 'SARC patient order differs.')
    with (root / 'patients.tsv').open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    ids = [r['case_submitter_id'] for r in rows]
    need(len(ids) == 250 and len(set(ids)) == 250 and
         all(int(r['row_index']) == i for i, r in enumerate(rows)), 'Invalid 250-case order.')
    records = {r['path']: r for r in c['files']}
    for view, (rel, expected, width) in INPUT_MATRICES.items():
        need(records[rel]['sha256'] == expected, 'Input manifest binding differs: ' + view)
    # No real molecular matrix is opened by this preflight.
    for rel in ('input_plan.json', 'report.json'):
        need(sha_file(root / rel) == records[rel]['sha256'], 'Input metadata SHA differs: ' + rel)
    report = load_json(root / 'report.json')
    need(report['model_fits'] == 0 and report['patients'] == 250, 'Unexpected staging state.')
    return root, ids, c


def stable_order(ids: list[str], namespace: str) -> list[int]:
    return sorted(range(len(ids)), key=lambda i: (
        hashlib.sha256(('sarc_limited_v1|' + namespace + '|' + ids[i]).encode()).hexdigest(), ids[i]))


def build_splits(ids: list[str]) -> list[dict[str, Any]]:
    need(len(ids) >= 25 and len(set(ids)) == len(ids), 'Duplicate or insufficient case IDs.')
    order = stable_order(ids, 'outer_20261009')
    parts = np.array_split(np.asarray(order, dtype=np.int64), 5)
    result = []
    for f, test in enumerate(parts, 1):
        test = sorted(int(i) for i in test)
        train = sorted(set(range(len(ids))) - set(test))
        ordered = sorted(train, key=lambda i: (
            hashlib.sha256(('sarc_limited_v1|early|' + str(f) + '|' + ids[i]).encode()).hexdigest(), ids[i]))
        n_early = max(2, int(math.ceil(0.20 * len(train))))
        early = sorted(ordered[:n_early]); fit = sorted(set(train) - set(early))
        row = {'fold': f, 'fit': fit, 'early': early, 'train': train, 'test': test}
        validate_split(row, len(ids))
        result.append(row)
    need(sorted(i for r in result for i in r['test']) == list(range(len(ids))), 'Test partition incomplete.')
    return result


def validate_split(split: dict[str, Any], n: int) -> None:
    for key in ('fit', 'early', 'train', 'test'):
        s = split[key]
        need(len(s) == len(set(s)) and all(type(i) is int and 0 <= i < n for i in s), 'Bad indices: ' + key)
    fit, early, train, test = (set(split[k]) for k in ('fit', 'early', 'train', 'test'))
    need(len(fit) >= 2 and len(early) >= 2 and len(test) >= 2, 'Too-small split.')
    need(not fit & early and fit | early == train and not train & test and train | test == set(range(n)),
         'Split overlap or incomplete train/test union.')


def protocol_core(runtime: dict[str, Any], ids: list[str]) -> dict[str, Any]:
    return {
        'version': 'SARC_LIMITED_FIXED_MODELS_V1',
        'status': 'PROSPECTIVE_EXTERNAL_PROTOCOL_NOT_EXECUTION_AUTHORIZATION',
        'cohort': 'TCGA-SARC; all 250 metadata-selected primary-tumor cases; no new case exclusions',
        'provenance_boundary': {'technical_QC_seen': True, 'historical_core_results_seen': True,
                               'SARC_model_performance_seen_before_protocol': False,
                               'historical_core_contracts_rewritten': False},
        'input_complete_sha256': INPUT_COMPLETE_SHA, 'patient_sha256': PATIENT_SHA,
        'input_matrices': INPUT_MATRICES, 'source_pins': SOURCE_PINS,
        'models': list(MODELS), 'neural_profile': asdict(runtime['profile']),
        'neural_variants': {m: asdict(runtime['variants'][m]) for m in NEURAL_MODELS},
        'selection': 'None. Report all three fixed models. Do not change TARGET V1 selection or 05e.',
        'CV': {'folds': 5, 'repeats': 1, 'stratification': 'none; outcome/biology-blind SHA256 case-ID order',
               'early_fraction_of_training': 0.2, 'neural_fit_seeds': list(SEEDS),
               'case_counts_per_fold': {'fit': 160, 'early': 40, 'refit': 200, 'test': 50},
               'neural_evaluation_records': 20, 'neural_optimization_runs': 40, 'PCA_fits': 5,
               'neural_epoch_policy': 'source early stopping, maximum 400/patience 30/min_delta .0001, same-seed reinitialization and train-all refit for selected epoch'},
        'preprocessing': {'fixed_input_transform': 'sarc4, unchanged', 'feature_budgets': BUDGETS,
                          'missing_fraction_max': {'RNA': 0.0, 'METHYLATION': 0.2, 'CNV': 0.0},
                          'variance': 'ddof=1, before z-score, strictly positive, stable original-index tiebreak',
                          'imputation': 'training median', 'scaling': 'training mean/sample SD after imputation',
                          'neural_PCA_per_view': PC_RANKS,
                          'early_stop_preprocessing': 'fit partition only; redo on train=fit+early for final fold refit',
                          'common_evaluation_features': 'same train-selected primary-budget features for all three models'},
        'baseline_difference_from_historical':
            'BLOCK_PCA_BUDGETED_K10: original 06b block-scaling/PCA mechanics, but primary budgets 5000/10000/5000 for this external task instead of all eligible features. Not the unchanged historical BLOCK_PCA row.',
        'endpoints': {
            'reconstruction_nmse': 'per-view observed TEST entries in selected molecular-feature space standardized with TRAIN parameters; neural predictions inverse-projected from per-view PCA. MSE divided by TRAIN observed-feature-centered null MSE; floor 1e-12. Report raw NMSE and mean across views (lower better), not imputed targets.',
            'omitted_view_nmse': 'same molecular space/mask/null; target view unavailable to shared representation and private input set to zero; per-view then equal-view mean (lower better)',
            'cross_view_MRR': 'exact 06b cross_view_mrr: train-scaled per-view embeddings, cosine test-to-test retrieval, six ordered directions, stable sample-index ties; raw and harmonic-null-adjusted clipped MRR',
            'seed_only_subspace_agreement': 'canonical subspace agreement between the two same-fold neural TEST representations; five descriptive fold values. No resampling, no truth, no retention decision.',
            'neural_heldout_collapse': 'effective_rank(TEST patient_shared)<2 OR median(sample variance)<1e-4; flag not exclusion',
        },
        'aggregation': 'average two neural seeds within each test fold, then five equal-sized folds; paired descriptive contrasts, no p-values or inferential confidence intervals; do not treat seeds/folds as independent cohorts',
        'failure': 'stop at first unexpected technical failure and preserve error; no seed/parameter rescue or successful-only primary average; previously completed records immutable',
        'excluded_scope': ['no outcomes/survival', 'no subtype or pathway selection', 'no new cohort search',
                           'no new model/architecture tuning', 'no .60 retention validation or biological truth recovery on SARC',
                           'no complete 80%-subsample stability or final full-cohort refit in this limited stage',
                           'no broad modern-method tournament', 'no historical-result replacement'],
        'interpretation': 'independent-cohort fixed-procedure application, not zero-shot transfer of TARGET weights, not proof of general biological correctness. V4 denotes its representation engine BEFORE retention here.',
        'synthetic': {'n': 250, 'small_widths': {'RNA': 48, 'METHYLATION': 64, 'CNV': 40},
                      'epochs_per_training_stage': SYNTHETIC_EPOCHS, 'empirical_SARC_values_used': False,
                      'budget_sized_preprocessing_fixture': {'n':250,'widths':[5016,10016,5016]}},
        'real_execution_requires': 'separate exact-source authorizer after review of this synthetic GPU report',
    }


def load_pointwise_inputs(root: Path, specs: dict[str, Any], n: int) -> dict[str, np.ndarray]:
    """Read-only, hash-bound loader. Caller must enforce REAL authorization separately.

    The sarc5 entry point calls this only on newly serialized ARTIFICIAL files.
    """
    output = {}
    try:
        for view in VIEWS:
            rel, expected_sha, width = specs[view]
            path = root / rel
            need(path.resolve().is_relative_to(root.resolve()), 'Input path escapes declared root.')
            need(sha_file(path) == expected_sha, 'Molecular input SHA mismatch: ' + view)
            a = np.load(path, mmap_mode='r', allow_pickle=False)
            output[view] = a
            need(a.shape == (n, int(width)) and a.dtype == np.dtype('<f4') and a.flags.c_contiguous,
                 'Molecular input dtype/geometry mismatch: ' + view)
            for start in range(0, n, 16):
                need(not np.isinf(a[start:start+16]).any(), 'Infinite molecular inputs: ' + view)
        return output
    except BaseException:
        close_inputs(output)
        raise


def close_inputs(matrices: dict[str, np.ndarray]) -> None:
    for a in matrices.values():
        mmap = getattr(a, '_mmap', None)
        if mmap is not None:
            mmap.close()


def prepared_views(runtime: dict[str, Any], matrices: dict[str, np.ndarray], split: dict[str, Any]) -> dict[str, Any]:
    n = next(iter(matrices.values())).shape[0]
    validate_split(split, n)
    need(all(x.ndim == 2 and x.shape[0] == n for x in matrices.values()), 'Input shapes differ.')
    target = runtime['target']
    fit = np.asarray(split['fit'], dtype=np.int64); train = np.asarray(split['train'], dtype=np.int64)
    early = np.asarray(split['early'], dtype=np.int64); test = np.asarray(split['test'], dtype=np.int64)
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Degrees of freedom <= 0 for slice', category=RuntimeWarning)
        prelim = target.fit_preprocessing_bundle(matrices, fit, BUDGETS, PC_RANKS)
        fit_pc = target.transform_bundle(prelim, matrices, fit, True)
        early_pc = target.transform_bundle(prelim, matrices, early, True)
        refit = target.fit_preprocessing_bundle(matrices, train, BUDGETS, PC_RANKS)
    train_pc = target.transform_bundle(refit, matrices, train, True)
    test_pc = target.transform_bundle(refit, matrices, test, True)
    train_std = target.transform_bundle(refit, matrices, train, False)
    test_std = target.transform_bundle(refit, matrices, test, False)
    raw_train_std = {}; raw_test_std = {}
    for v in VIEWS:
        tr = refit['transforms'][v]
        for ix, dest in ((train, raw_train_std), (test, raw_test_std)):
            raw = np.asarray(matrices[v][ix][:, tr.selected_indices], dtype=np.float64)
            need(not np.isinf(raw).any() and np.all(np.isfinite(raw).sum(axis=1) > 0),
                 v + ': at least one row has no observed selected features; do not silently drop it.')
            dest[v] = (raw - tr.means) / tr.scales
        need(train_pc[v].shape[1] == 10 and test_pc[v].shape[1] == 10,
             v + ': fewer than 10 usable per-view PCs; do not pad silently.')
    return {'prelim': prelim, 'refit': refit, 'fit_pc': fit_pc, 'early_pc': early_pc,
            'train_pc': train_pc, 'test_pc': test_pc, 'train_std': train_std, 'test_std': test_std,
            'raw_train_std': raw_train_std, 'raw_test_std': raw_test_std}


def observed_nmse(train: np.ndarray, test: np.ndarray, prediction: np.ndarray) -> dict[str, Any]:
    train = np.asarray(train, dtype=np.float64); test = np.asarray(test, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    need(train.ndim == test.ndim == prediction.ndim == 2 and prediction.shape == test.shape and
         train.shape[1] == test.shape[1], 'NMSE shape mismatch.')
    need(not np.isinf(train).any() and not np.isinf(test).any() and np.isfinite(prediction).all(),
         'Nonfinite prediction/invalid target; cannot mask away model failure.')
    tm = np.isfinite(train); mask = np.isfinite(test)
    need(tm.any() and mask.any() and np.all(tm.sum(axis=0) > 0), 'NMSE has unobserved denominator/target.')
    center = np.sum(np.where(tm, train, 0.0), axis=0) / tm.sum(axis=0)
    null = float(np.sum(np.where(tm, (train - center)**2, 0.0)) / tm.sum())
    sse_rows = np.sum(np.where(mask, (test - prediction)**2, 0.0), axis=1)
    counts = mask.sum(axis=1)
    mse = float(sse_rows.sum() / counts.sum())
    return {'nmse': mse / max(null, 1e-12), 'mse': mse, 'train_null_mse': null,
            'n_observed_test_entries': int(counts.sum()),
            'test_row_sse': sse_rows.tolist(), 'test_row_counts': counts.tolist()}


def effective_rank(x: np.ndarray) -> float:
    a = np.asarray(x, dtype=np.float64); a = a - a.mean(axis=0)
    s = np.linalg.svd(a, compute_uv=False)**2
    if not s.size or s.sum() <= 0:
        return 0.0
    p = s[s > 0] / s.sum()
    return float(np.exp(-np.sum(p * np.log(p))))


def subspace_agreement(x: np.ndarray, y: np.ndarray) -> dict[str, Any]:
    def basis(a):
        a = np.asarray(a, dtype=np.float64)
        need(a.ndim == 2 and np.isfinite(a).all(), 'Invalid latent agreement input.')
        a = a - a.mean(axis=0)
        u, s, _ = np.linalg.svd(a, full_matrices=False)
        tol = max(a.shape) * np.finfo(float).eps * (s[0] if len(s) else 0.0)
        return u[:, s > tol]
    need(x.shape[0] == y.shape[0], 'Agreement row count differs.')
    a, b = basis(x), basis(y)
    if min(a.shape[1], b.shape[1]) == 0:
        return {'status': 'UNDEFINED_ZERO_RANK', 'value': None, 'rank_left': a.shape[1], 'rank_right': b.shape[1]}
    c = np.clip(np.linalg.svd(a.T @ b, compute_uv=False), 0.0, 1.0)
    return {'status': 'DESCRIPTIVE_SEED_ONLY', 'value': float(c.mean()),
            'rank_left': a.shape[1], 'rank_right': b.shape[1]}


def evaluate_fixed_model(runtime: dict[str, Any], p: dict[str, Any], model_id: str, seed: int,
                         smoke: bool = False) -> dict[str, Any]:
    """Future scientific executor must call this SAME function, under separate authorization."""
    target, ablation = runtime['target'], runtime['ablation']
    started = time.perf_counter(); model = None
    n_test = next(iter(p['test_pc'].values())).shape[0]
    n_train = next(iter(p['train_pc'].values())).shape[0]
    fit_audits = []
    omission_valid = {}
    try:
        if model_id == MODELS[0]:
            need(seed == 0, 'Deterministic PCA is evaluated once, not replicated per neural seed.')
            model = target.fit_block_pca(p['train_std'], rank=10)
            reconstruction = model.reconstruct(p['test_std'])
            omitted = {v: model.reconstruct(p['test_std'], included=set(VIEWS)-{v})[v] for v in VIEWS}
            train_emb, test_emb = model.view_embeddings(p['train_std']), model.view_embeddings(p['test_std'])
            latent = model.shared_scores(p['test_std'])
            epoch = None
            omission_valid = {v: True for v in VIEWS}
        else:
            need(model_id in NEURAL_MODELS and seed in SEEDS, 'Unexpected fixed model/seed.')
            profile = replace(runtime['profile'], maximum_epochs=SYNTHETIC_EPOCHS, patience=2) if smoke else runtime['profile']
            av_fit = np.ones((len(next(iter(p['fit_pc'].values()))), 3), dtype=bool)
            av_early = np.ones((len(next(iter(p['early_pc'].values()))), 3), dtype=bool)
            epoch, early_audit = ablation.train_with_early_stopping(
                runtime['neural'], profile, runtime['variants'][model_id], p['fit_pc'], av_fit,
                p['early_pc'], av_early, int(seed))
            need(type(epoch) is int and 1 <= epoch <= profile.maximum_epochs, 'Invalid selected epoch.')
            av_train = np.ones((n_train, 3), dtype=bool); av_test = np.ones((n_test, 3), dtype=bool)
            model, refit_audit = ablation.train_fixed_epochs(
                runtime['neural'], profile, runtime['variants'][model_id], p['train_pc'], av_train, int(seed), epoch)
            fit_audits = [early_audit, refit_audit]
            for a in fit_audits:
                for k, v in a.items():
                    if isinstance(v, (float, np.floating)):
                        need(math.isfinite(float(v)), 'Nonfinite training audit: ' + k)
            train_enc = ablation.encode_numpy(model, p['train_pc'], av_train)
            test_enc = ablation.encode_numpy(model, p['test_pc'], av_test)
            train_emb, test_emb = train_enc['shared_by_view'], test_enc['shared_by_view']
            latent = test_enc['patient_shared']
            pc_recon = ablation.predict_reconstruction_numpy(model, p['test_pc'], av_test)
            reconstruction = {v: p['refit']['pcas'][v].inverse(pc_recon[v]) for v in VIEWS}
            omitted = {}
            for v in VIEWS:
                pred, valid = ablation.predict_missing_view_numpy(model, p['test_pc'], av_test, v)
                need(np.asarray(valid).shape == (n_test,) and np.asarray(valid).all(), 'Omitted-view projection invalid.')
                omitted[v] = p['refit']['pcas'][v].inverse(pred)
                if smoke:
                    changed = dict(p['test_pc']); changed[v] = np.full_like(changed[v], 12345.0)
                    pred2, valid2 = ablation.predict_missing_view_numpy(model, changed, av_test, v)
                    need(np.array_equal(pred, pred2) and np.array_equal(valid, valid2), 'Omitted target leaked into prediction.')
                omission_valid[v] = True
        need(np.asarray(latent).shape == (n_test, 10 if model_id == MODELS[0] else 5) and np.isfinite(latent).all(),
             'Invalid latent geometry/values.')
        if smoke and model_id == MODELS[0]:
            for v in VIEWS:
                changed = dict(p['test_std']); changed[v] = np.full_like(changed[v], -12345.0)
                pred2 = model.reconstruct(changed, included=set(VIEWS)-{v})[v]
                need(np.array_equal(omitted[v], pred2), 'PCA omitted target leaked into prediction.')
        rec = {v: observed_nmse(p['raw_train_std'][v], p['raw_test_std'][v], reconstruction[v]) for v in VIEWS}
        miss = {v: observed_nmse(p['raw_train_std'][v], p['raw_test_std'][v], omitted[v]) for v in VIEWS}
        mrr, adjusted = target.cross_view_mrr(train_emb, test_emb)
        rank = effective_rank(latent); median_var = float(np.median(np.var(latent, axis=0, ddof=1)))
        result = {'model_id': model_id, 'seed': int(seed), 'status': 'PASS',
                  'scope': 'ARTIFICIAL_SELFTEST' if smoke else 'SARC_FIXED_MODEL_EXTERNAL',
                  'selected_epoch': epoch, 'reconstruction': rec, 'omitted_view': miss,
                  'reconstruction_nmse': float(np.mean([x['nmse'] for x in rec.values()])),
                  'omitted_view_nmse': float(np.mean([x['nmse'] for x in miss.values()])),
                  'raw_cross_view_mrr': float(mrr), 'adjusted_cross_view_mrr': float(adjusted),
                  'latent_effective_rank': rank, 'latent_median_variance': median_var,
                  'neural_heldout_collapse': bool(rank < 2 or median_var < 1e-4) if model_id != MODELS[0] else None,
                  'fit_audits': fit_audits, 'latent': np.asarray(latent).tolist(),
                  'omission_invariance_checked': omission_valid if smoke else None,
                  'elapsed_seconds': time.perf_counter()-started}
        json_bytes(result)  # All result payloads must be JSON-finite.
        return result
    finally:
        if model is not None:
            del model
        gc.collect()
        import torch
        if torch.cuda.is_initialized():
            torch.cuda.empty_cache()


def preprocessor_digest(prep: dict[str, Any]) -> str:
    h = hashlib.sha256()
    for v in VIEWS:
        t = prep['transforms'][v]; pc = prep['pcas'][v]
        for a in (t.selected_indices, t.medians, t.means, t.scales, pc.mean, pc.components):
            a = np.ascontiguousarray(a)
            h.update(str(a.dtype).encode()); h.update(str(a.shape).encode()); h.update(a.tobytes())
    return h.hexdigest()


def synthetic_matrices() -> tuple[dict[str, np.ndarray], list[str]]:
    rng = np.random.default_rng(2026100905)
    n = 250; z = rng.normal(size=(n, 5))
    data = {}
    for v, d in zip(VIEWS, (48, 64, 40)):
        x = (z @ rng.normal(size=(5, d)) + 0.6*rng.normal(size=(n, d))).astype(np.float32)
        x[:, 0] = 0.0; x[:, 1] = np.nan
        if v == 'METHYLATION':
            mask = rng.random((n, d)) < .08; x[mask] = np.nan
            x[:100, 2] = np.nan
        data[v] = x
    return data, ['ARTIFICIAL_%03d' % i for i in range(n)]


def _synthetic_loaded_path(runtime: dict[str, Any], matrices: dict[str, np.ndarray], ids: list[str]) -> dict[str, Any]:
    splits = build_splits(ids)
    results = []; agreements = []; n_training_stages = 0
    budget_rng = np.random.default_rng(2026100906)
    big = {v: budget_rng.normal(size=(250,d)).astype(np.float32)
           for v,d in zip(VIEWS,(5016,10016,5016))}
    for v in VIEWS:
        big[v][:,0] = np.nan; big[v][:,1] = 0.0
    budget_start = time.perf_counter()
    budget_p = prepared_views(runtime,big,splits[0])
    actual_budgets = {v: len(budget_p['refit']['transforms'][v].selected_indices) for v in VIEWS}
    need(actual_budgets == BUDGETS, 'Synthetic primary budgets not reached.')
    budget_check = {'status':'PASS','selected':actual_budgets,'seconds':time.perf_counter()-budget_start,
                    'n':250,'source_widths':{v:list(x.shape) for v,x in big.items()}}
    del budget_p,big; gc.collect()
    print('Artificial 250-row primary-budget preprocessing / dual PCA: PASS', flush=True)
    for split in splits:
        p = prepared_views(runtime, matrices, split)
        if split['fold'] == 1:
            altered = {v: x.copy() for v, x in matrices.items()}
            for v in VIEWS:
                altered[v][split['test'], 3:] = 9999.0
            q = prepared_views(runtime, altered, split)
            need(preprocessor_digest(p['prelim']) == preprocessor_digest(q['prelim']) and
                 preprocessor_digest(p['refit']) == preprocessor_digest(q['refit']), 'Held-out data affected preprocessing.')
            del q, altered
        fold_results = {}
        for model in MODELS:
            for seed in ((0,) if model == MODELS[0] else SEEDS):
                r = evaluate_fixed_model(runtime, p, model, seed, smoke=True)
                r['fold'] = split['fold']; results.append(r); fold_results[(model,seed)] = r
                n_training_stages += len(r['fit_audits'])
                print('Synthetic fold %d/5 %s seed=%d: PASS' % (split['fold'],model,seed), flush=True)
        for model in NEURAL_MODELS:
            x, y = (np.asarray(fold_results[(model,s)]['latent']) for s in SEEDS)
            agreements.append({'fold': split['fold'], 'model_id': model, **subspace_agreement(x,y)})
        del p
    need(len(results)==25 and n_training_stages==40, 'Synthetic path incomplete.')
    need(runtime['profile'].maximum_epochs == 400, 'Synthetic profile mutated scientific epochs.')
    return {'status': 'PASS_ARTIFICIAL_5FOLD_2SEED_COMMON_ENDPOINT_PATH', 'evaluation_records': 25,
            'neural_optimization_runs': 40, 'PCA_fits': 5, 'max_epochs_per_synthetic_training_stage': 2,
            'real_SARC_values_used': False, 'data_shape': {v:list(x.shape) for v,x in matrices.items()},
            'results': results, 'seed_only_subspace_agreement': agreements, 'budget_sized_preprocessing':budget_check,
            'test_preprocessing_leakage_check': 'PASS', 'omitted_view_input_invariance': 'PASS',
            'scientific_profile_unchanged': True}


def synthetic_full_path(runtime: dict[str, Any]) -> dict[str, Any]:
    original, ids = synthetic_matrices()
    with tempfile.TemporaryDirectory(prefix='sarc5_ARTIFICIAL_ONLY_') as td:
        root = Path(td); specs = {}
        for view in VIEWS:
            p = root / (view + '.npy')
            with p.open('xb') as f:
                np.save(f, original[view], allow_pickle=False)
            specs[view] = (p.name, sha_file(p), original[view].shape[1])
        matrices = load_pointwise_inputs(root, specs, len(ids))
        try:
            for view in VIEWS:
                need(np.array_equal(matrices[view], original[view], equal_nan=True),
                     'Artificial serialized loader changed matrix values.')
            report = _synthetic_loaded_path(runtime, matrices, ids)
            for view, (rel, digest, width) in specs.items():
                need(sha_file(root/rel) == digest, 'Artificial input changed during fitting.')
            report['serialized_readonly_production_loader'] = 'PASS'
            return report
        finally:
            close_inputs(matrices)


def cuda_environment() -> dict[str, Any]:
    import torch
    need(str(torch.__version__) == '2.12.1+cu130', 'Use the existing exact MOVE/CUDA environment; do not update it.')
    need(str(torch.version.cuda) == '13.0' and torch.cuda.is_available(), 'Exact CUDA 13 build/GPU required.')
    need(np.__version__ == '1.26.4', 'NumPy differs from sarc4 environment; stop, do not reinstall blindly.')
    torch.cuda.init(); torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(2)
    return {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
            'numpy': np.__version__, 'pandas': pd.__version__, 'torch': str(torch.__version__),
            'cuda': str(torch.version.cuda), 'GPU': torch.cuda.get_device_name(0),
            'TF32': False, 'AMP': False, 'torch_compile': False, 'cpu_threads': 2,
            'CUBLAS_WORKSPACE_CONFIG': os.environ['CUBLAS_WORKSPACE_CONFIG']}


def evidence_zip(parallel: Path, out: Path) -> Path:
    dest = parallel / ('s5small_' + out.name.removeprefix('session_') + '.zip')
    entries = [p for p in sorted(out.rglob('*')) if p.is_file()]
    root = out.parent.parent
    entries += [root/'fixed_protocol.json', root/'split_registry.json', root/'sarc5_source.py']
    entries = [p for p in entries if p.is_file()]
    need(sum(p.stat().st_size for p in entries) < 15*1024*1024, 'Unexpected report size; refuse molecular-data export.')
    with zipfile.ZipFile(dest, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in entries:
            z.write(p, p.relative_to(root).as_posix())
    need(dest.stat().st_size <= MAX_EVIDENCE_BYTES, 'Evidence ZIP exceeds 5 MiB; do not upload model arrays.')
    return dest


def main() -> None:
    here = Path(__file__).resolve(); parallel = here.parent; project = parallel.parent
    need(here.name == 'sarc5.py' and parallel.name == 'paper5_parallel_sarc', 'Keep sarc5.py in paper5_parallel_sarc.')
    print('SARC limited protocol + ARTIFICIAL model preflight; NO real cohort fitting', flush=True)
    print('Version: ' + VERSION, flush=True)
    need(sys.version_info[:2] == (3,10), 'Use the existing Python 3.10 interpreter.')
    outroot = parallel/'limited_model_v1'
    with process_lock(outroot/'.sarc5.lock'):
        need(not (outroot/'scientific_results').exists(), 'Scientific results already exist; do not rerun preflight.')
        source_before = verify_sources(project)
        _, ids, _ = verify_input_metadata(parallel)
        runtime = load_runtime(project)
        plan = protocol_core(runtime, ids); plan['sarc5_source_sha256'] = sha_file(here)
        splits = {'case_ids': ids, 'splits': build_splits(ids), 'protocol_version': plan['version']}
        write_or_verify(outroot/'fixed_protocol.json', json_bytes(plan))
        write_or_verify(outroot/'split_registry.json', json_bytes(splits))
        write_or_verify(outroot/'sarc5_source.py', here.read_bytes())
        done = outroot/'synthetic_preflight_lock.json'
        if done.exists():
            old = load_json(done)
            need(old['source_sha256']==sha_file(here) and old['protocol_sha256']==sha_file(outroot/'fixed_protocol.json') and
                 old['split_sha256']==sha_file(outroot/'split_registry.json'), 'Existing preflight identity differs.')
            for rec in old['records']:
                need(sha_file(outroot/rec['path'])==rec['sha256'], 'Existing preflight result changed.')
            print('Existing exact synthetic preflight: PASS; real execution still NOT AUTHORIZED.')
            print('Evidence ZIP: ' + str(parallel/old['evidence_zip_name']))
            return
        session_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
        out = outroot/'sessions'/('session_'+session_id); out.mkdir(parents=True, exist_ok=False)
        result = {'version':VERSION, 'started_at_utc':datetime.now(timezone.utc).isoformat(),
                  'real_SARC_matrices_decoded':False, 'clinical_outcomes_read':False, 'model_authorization_created':False}
        ok=False
        try:
            result['environment']=cuda_environment()
            print('Pinned inputs (metadata only) and five runtime sources: PASS', flush=True)
            print('Limited protocol and 5 folds saved BEFORE synthetic fits; real matrix access: FORBIDDEN', flush=True)
            result['synthetic']=synthetic_full_path(runtime)
            need(source_before==verify_sources(project), 'Historical source changed during preflight.')
            verify_input_metadata(parallel)
            result['status']='LIMITED_PROTOCOL_AND_SYNTHETIC_PATH_PASS_NOT_AUTHORIZED'
            ok=True
        except Exception as exc:
            result['status']='SYNTHETIC_PREFLIGHT_INCOMPLETE_NOT_AUTHORIZED'
            result['error']=f'{type(exc).__name__}: {exc}'
            result['traceback']=traceback.format_exc()
        result['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        write_new(out/'report.json', json_bytes(result))
        packet=evidence_zip(parallel,out)
        if ok:
            lock={'status':'SYNTHETIC_ONLY_NOT_REAL_AUTHORIZATION','source_sha256':sha_file(here),
                  'protocol_sha256':sha_file(outroot/'fixed_protocol.json'),
                  'split_sha256':sha_file(outroot/'split_registry.json'),
                  'records':[{'path':(out/'report.json').relative_to(outroot).as_posix(),'sha256':sha_file(out/'report.json')}],
                  'evidence_zip_name':packet.name, 'evidence_zip_sha256':sha_file(packet)}
            write_new(done,json_bytes(lock))
        print('Status: '+result['status'])
        if not ok: print(result['traceback'])
        print('Evidence ZIP (send this FILE): '+str(packet))
        print('Evidence ZIP bytes: '+str(packet.stat().st_size))
        print('Evidence ZIP SHA-256: '+sha_file(packet))
        print('Real SARC fitting: NO. No historical data/locks/results modified. Stop after this report.')
        if not ok: raise SystemExit(2)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('SARC5 STOPPED: '+type(exc).__name__+': '+str(exc))
        print('No real cohort fitting authorized. Do not edit input files or hashes.')
        raise SystemExit(2)
