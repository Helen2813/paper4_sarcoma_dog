from __future__ import annotations

"""Execute the fixed limited SARC protocol, ONLY after sarc6a source authorization.

This module imports only the standard library until authorization is verified.
Numerical work is delegated to the exact, unchanged sarc5.py implementation
that passed the user's 25-record Windows/CUDA artificial preflight.
No CLI switches, no threshold search, no silent retries, no historical writes.
"""
import contextlib
import csv
import gc
import hashlib
import importlib.util
import io
import json
import math
import os
import sys
import traceback
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

sys.dont_write_bytecode = True
VERSION = 'sarc6-fixed-sarc5-numerics-authorized-limited-external-run-v1-no-cli'
AUTH_VERSION = 'sarc6a-freeze-exact-limited-external-executor-v1-no-fit'
AUTH_STATUS = 'FROZEN_LIMITED_SARC_EXECUTION_AUTHORIZATION'
COMPLETE_STATUS = 'LIMITED_SARC_FIXED_MODEL_BENCHMARK_COMPLETE_FROZEN'
HISTORY = [('parallel', 'sarc5.py', 'dd16e547972d8d298491e2d3c5003dea16760e969e9ea846fda5b0f83020f96f'),
 ('parallel',
  'limited_model_v1/sarc5_source.py',
  'dd16e547972d8d298491e2d3c5003dea16760e969e9ea846fda5b0f83020f96f'),
 ('parallel',
  'limited_model_v1/fixed_protocol.json',
  'f3a63188ecbaff4a5164d999d933a5f6481ff7d0560b999022faa38f7a0cfff8'),
 ('parallel',
  'limited_model_v1/split_registry.json',
  '78a702ac43d55dd37f8b194b7b7933fb547f09e04cf6333662b57221160377f0'),
 ('parallel',
  'limited_model_v1/synthetic_preflight_lock.json',
  'ed7fb8dc9ffbbe94b0e8749358b859dc706c44f75bc2c1433c2c52d3de343edb'),
 ('parallel',
  'limited_model_v1/sessions/session_20261010T025039Z_0d8d8342/report.json',
  '0628fce1629fad130e125cc67b2f8d59e3da53ff06c836e96f446b9c15c361b7'),
 ('parallel',
  'pointwise_inputs_v1/sarc4_20261010T015241Z_dbf619ed/input_complete.json',
  '81a0c365e9b7d62af957161350f7fabc4de700785285aab16d8436d89e863265'),
 ('parallel',
  'pointwise_inputs_v1/sarc4_20261010T015241Z_dbf619ed/patients.tsv',
  'e279425a714649c30a409d091fd9c819b86e2912784e9413a53e21d7ccfdde3f'),
 ('parallel',
  'pointwise_inputs_v1/sarc4_20261010T015241Z_dbf619ed/input_plan.json',
  '7e4c6ff2b44b5e2e0c2db70f458217bd7e3ed00d32fc12595bcb1113e45882c5'),
 ('parallel',
  'pointwise_inputs_v1/sarc4_20261010T015241Z_dbf619ed/report.json',
  '0f215e0c3020c18f87ed18f388993e2fb49d221155ab51063e1a80f516d82ef5'),
 ('project',
  'paper5/scripts/06b_run_target_outcome_blind_representation_benchmark_gpu_v4.py',
  '4f69680a2d26d6c8e4bd5b337a5e94e6cdc36d149ea6a4b9af547b3855a93eab'),
 ('project',
  'paper5/scripts/05d2v2_screen_neural_profiles_gpu_syncfree_pathfix.py',
  '05ae6923ce588c137bc6f4aa934262181dd99f4ebe6bec3250e4b7cd54ed1ff3'),
 ('project',
  'paper5/scripts/05d4_fit_neural_ablation_benchmark_gpu_v1_2_verified.py',
  '8ab3b84f1d7bcd475b88b5f06d49e661c2d6230ea3598406e66970d792c74a5c'),
 ('project',
  'paper5/method_contract/05d1/neural_architecture_regularization_profile_grid.csv',
  '118b2fd4c16751f0b83ac3053f726f9421db26949ab98a8a531ff584c194ee32'),
 ('project',
  'paper5/method_contract/05d1/neural_loss_and_architecture_contract.json',
  'b90ded1d011ee3210154c2102389df0b4e0c8fcf668b70d7e2b8e14184e3f6b1')]
S5_SHA = 'dd16e547972d8d298491e2d3c5003dea16760e969e9ea846fda5b0f83020f96f'
REPORT_REL = 'limited_model_v1/sessions/session_20261010T025039Z_0d8d8342/report.json'
AUTH_REL = 'limited_model_v1/authorization_v1/sarc6_source_authorization.json'
RESULT_REL = 'limited_model_v1/scientific_results'
PREFLIGHT_REL = 'limited_model_v1/synthetic_preflight_lock.json'
PROTOCOL_REL = 'limited_model_v1/fixed_protocol.json'
SPLITS_REL = 'limited_model_v1/split_registry.json'
INPUT_RUN = 'pointwise_inputs_v1/sarc4_20261010T015241Z_dbf619ed'
MODELS = ('BLOCK_PCA_BUDGETED_K10', 'V1_SHARED_PRIVATE_AE', 'V4_SABLE_MO')
NEURAL_MODELS = MODELS[1:]
SEEDS = (1103, 2207)
VIEWS = ('RNA', 'METHYLATION', 'CNV')
SUMMARY_METRICS = ('reconstruction_nmse', 'omitted_view_nmse', 'raw_cross_view_mrr', 'adjusted_cross_view_mrr')
CONTRASTS = ((MODELS[2],MODELS[1]), (MODELS[1],MODELS[0]), (MODELS[2],MODELS[0]))
REPORT_SHA = '0628fce1629fad130e125cc67b2f8d59e3da53ff06c836e96f446b9c15c361b7'
EXPECTED_ENV = {'AMP': False,
 'CUBLAS_WORKSPACE_CONFIG': ':4096:8',
 'GPU': 'NVIDIA GeForce RTX 4080 Laptop GPU',
 'TF32': False,
 'cpu_threads': 2,
 'cuda': '13.0',
 'numpy': '1.26.4',
 'pandas': '2.3.3',
 'torch': '2.12.1+cu130',
 'torch_compile': False}
MAX_ZIP = 5 * 1024 * 1024


def need(ok: Any, message: str) -> None:
    if not bool(ok):
        raise RuntimeError(message)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, ensure_ascii=True, indent=2, allow_nan=False)+'\n').encode('utf-8')


def safe_path(root: Path, rel: str) -> Path:
    pp = PurePosixPath(rel)
    need(isinstance(rel,str) and '\\' not in rel and not pp.is_absolute() and
         all(p not in ('', '.', '..') and ':' not in p for p in pp.parts), 'Unsafe relative path: '+str(rel))
    path = root.joinpath(*pp.parts)
    need(path.resolve().is_relative_to(root.resolve()), 'Path escapes permitted root: '+rel)
    walk = path
    while walk != root:
        need(not walk.is_symlink(), 'Symbolic link not accepted: '+str(walk))
        walk = walk.parent
    return path


def sha_file(path: Path) -> str:
    need(path.is_file() and not path.is_symlink(), 'Required file missing/non-regular: '+str(path))
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def load_json(path: Path) -> Any:
    need(path.is_file() and path.stat().st_size<=20*1024*1024, 'Missing/oversized JSON: '+str(path))
    def pairs(items):
        out={}
        for k,v in items:
            need(k not in out,'Duplicate JSON key: '+k);out[k]=v
        return out
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON: '+x)))


def record(path: Path, root: Path) -> dict[str, Any]:
    return {'path':path.relative_to(root).as_posix(),'sha256':sha_file(path),'size_bytes':path.stat().st_size}


def verify_record(root: Path, rec: dict[str, Any]) -> None:
    p=safe_path(root,rec['path'])
    need(p.is_file() and p.stat().st_size==rec['size_bytes'] and sha_file(p)==rec['sha256'],
         'Stored bytes changed: '+rec['path'])


def publish_json(path: Path, data: Any) -> None:
    """Atomic create via hard link: no overwriting, even if another writer races.

    Temp bytes and the final name share a directory. Windows NTFS and the tested
    POSIX filesystem support this; an unsupported filesystem causes a hard stop.
    Completed artifacts are never silently replaced.
    """
    publish_bytes(path,canonical(data))


def publish_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    need(not path.exists(),'Refusing to overwrite: '+str(path))
    temp=path.parent/('.writing_'+path.name+'_'+uuid.uuid4().hex)
    with temp.open('xb') as f:
        f.write(data);f.flush();os.fsync(f.fileno())
    try:
        os.link(temp,path)
    except BaseException:
        # Keep the uncommitted bytes as evidence. Do not fall back to overwrite.
        raise
    else:
        temp.unlink()


def verify_or_publish(path: Path, data: bytes) -> None:
    if path.exists():
        need(path.read_bytes()==data,'Existing derived artifact differs: '+str(path))
    else:
        publish_bytes(path,data)


@contextlib.contextmanager
def process_lock(path: Path):
    path.parent.mkdir(parents=True,exist_ok=True)
    f=path.open('a+b');f.seek(0,2)
    if not f.tell():f.write(b'0');f.flush()
    f.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError as e:
        f.close();raise RuntimeError('Another SARC5/SARC6 process is active. Do not delete the lock.') from e
    try:yield
    finally:
        f.seek(0)
        if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
        else:fcntl.flock(f.fileno(),fcntl.LOCK_UN)
        f.close()


def expected_jobs() -> list[tuple[int,str,int]]:
    return [(f,m,s) for f in range(1,6) for m in MODELS for s in ((0,) if m==MODELS[0] else SEEDS)]


def job_name(fold: int, model: str, seed: int) -> str:
    need((fold,model,seed) in expected_jobs(),'Unknown job identity')
    return 'F%02d__%s__S%d' % (fold,model,seed)


def structural_report_check(r: dict[str, Any]) -> None:
    need(r['status']=='LIMITED_PROTOCOL_AND_SYNTHETIC_PATH_PASS_NOT_AUTHORIZED', 'Synthetic report not PASS')
    need(r['version']=='sarc5-limited-external-protocol-and-synthetic-model-path-v1-no-real-fit', 'Preflight version')
    need(r['real_SARC_matrices_decoded'] is False and r['clinical_outcomes_read'] is False and
         r['model_authorization_created'] is False,'Preflight scientific boundary violated')
    s=r['synthetic']
    need(s['evaluation_records']==25 and s['neural_optimization_runs']==40 and s['PCA_fits']==5,
         'Synthetic model schedule incomplete')
    need(s['real_SARC_values_used'] is False and s['scientific_profile_unchanged'] is True,
         'Synthetic scientific scope/profile changed')
    need(s['max_epochs_per_synthetic_training_stage']==2,'Wrong synthetic epoch budget')
    for key in ('test_preprocessing_leakage_check','omitted_view_input_invariance','serialized_readonly_production_loader'):
        need(s[key]=='PASS','Synthetic check failed: '+key)
    b=s['budget_sized_preprocessing']
    need(b['status']=='PASS' and b['n']==250 and b['selected']=={'RNA':5000,'METHYLATION':10000,'CNV':5000},
         'Synthetic primary budgets not verified')
    jobs=[(x['fold'],x['model_id'],x['seed']) for x in s['results']]
    need(len(jobs)==25 and set(jobs)==set(expected_jobs()),'Missing/duplicate synthetic job')
    for x in s['results']:
        need(x['status']=='PASS' and x['scope']=='ARTIFICIAL_SELFTEST', 'Bad synthetic record')
        need(x['omission_invariance_checked']==dict.fromkeys(VIEWS,True), 'Omission invariant absent')
        if x['model_id'] in NEURAL_MODELS:
            a=x['fit_audits']
            need(len(a)==2 and all(y['fit_status']=='PASS' and y['device']=='cuda:0' and
                                  y['fit_seed']==x['seed'] for y in a), 'CUDA artificial training failed')
            need(a[0]['maximum_epochs']==2 and a[1]['epochs_run']==x['selected_epoch'], 'Synthetic refit invalid')
    for k,v in EXPECTED_ENV.items():
        need(r['environment'].get(k)==v,'Synthetic environment differs: '+k)


def verify_static(parallel: Path) -> dict[str, Any]:
    """Read pinned metadata/code only, never import project code or read .npy bytes."""
    project=parallel.parent
    pins=[]
    for scope, rel, digest in HISTORY:
        root=parallel if scope=='parallel' else project
        p=safe_path(root,rel)
        need(sha_file(p)==digest,'Historical SHA differs: '+scope+'/'+rel)
        pins.append({'scope':scope, **record(p,root)})
    plan=load_json(parallel/PROTOCOL_REL);splits=load_json(parallel/SPLITS_REL)
    need(plan['sarc5_source_sha256']==S5_SHA and plan['models']==list(MODELS), 'Protocol/model identity mismatch')
    need(plan['CV']['neural_fit_seeds']==list(SEEDS) and plan['CV']['neural_optimization_runs']==40,
         'Fixed schedule changed')
    need(plan['neural_profile']['maximum_epochs']==400 and plan['neural_profile']['patience']==30,
         'Scientific profile changed')
    need(len(splits['case_ids'])==250 and len(set(splits['case_ids']))==250 and len(splits['splits'])==5,'Invalid split registry')
    for f,s in enumerate(splits['splits'],1):
        need(s['fold']==f and all(type(i) is int and 0<=i<250 for k in ('fit','early','train','test') for i in s[k]),'Invalid fold')
        sets={k:set(s[k]) for k in ('fit','early','train','test')}
        need([len(s[k]) for k in ('fit','early','train','test')]==[160,40,200,50] and
             all(len(sets[k])==len(s[k]) for k in sets),'Fold size/duplicate indices')
        need(not sets['fit']&sets['early'] and sets['fit']|sets['early']==sets['train'] and
             not sets['test']&sets['train'] and sets['test']|sets['train']==set(range(250)),'Fold overlap')
    need(sorted(i for s in splits['splits'] for i in s['test'])==list(range(250)), 'Held-out partition differs')
    with (parallel/INPUT_RUN/'patients.tsv').open(encoding='utf-8-sig',newline='') as f:
        ids=[r['case_submitter_id'] for r in csv.DictReader(f,delimiter='\t')]
    need(ids==splits['case_ids'],'Patient row order differs')
    report=load_json(parallel/REPORT_REL);structural_report_check(report)
    lock=load_json(parallel/PREFLIGHT_REL)
    need(lock['status']=='SYNTHETIC_ONLY_NOT_REAL_AUTHORIZATION' and lock['source_sha256']==S5_SHA,
         'Wrong synthetic lock')
    need(lock['records']==[{'path':REPORT_REL.removeprefix('limited_model_v1/'),'sha256':REPORT_SHA}], 'Synthetic report lock mismatch')
    need(lock['protocol_sha256']==sha_file(parallel/PROTOCOL_REL) and
         lock['split_sha256']==sha_file(parallel/SPLITS_REL),'Preflight protocol binding mismatch')
    c=load_json(parallel/INPUT_RUN/'input_complete.json')
    recs={v['path']:v for v in c['files']}
    for v,(rel,digest,width) in plan['input_matrices'].items():
        need(recs[rel]['sha256']==digest,'Matrix manifest identity differs: '+v)
        path=safe_path(parallel/INPUT_RUN,rel)
        need(path.is_file() and path.stat().st_size==recs[rel]['size_bytes'], 'Matrix missing/size mismatch: '+v)
    return {'files':pins,'plan':plan,'splits':splits,'input_complete':c,'report':report}


def verify_authorization(parallel: Path, executor: Path, state: dict[str, Any]) -> dict[str, Any]:
    auth=load_json(parallel/AUTH_REL)
    need(auth['status']==AUTH_STATUS and auth['authorizer_version']==AUTH_VERSION,'Real SARC not authorized')
    need(auth['executor']==record(executor,parallel),'Executor source SHA/path not authorized')
    need(auth['historical_inputs']==state['files'],'Authorization source/protocol/preflight pins differ')
    need(auth['scientific_results_rel']==RESULT_REL and auth['numerical_implementation_sha256']==S5_SHA,
         'Unexpected execution namespace/helper binding')
    need(auth['expected_environment']==EXPECTED_ENV,'Authorized environment differs')
    verify_record(parallel,auth['authorizer'])
    need(auth['authorizer']['path']=='sarc6a.py','Unexpected authorizer path')
    need(auth['scientific_benchmark_started'] is False and auth['real_matrix_values_opened'] is False,
         'Authorization preexecution boundary differs')
    return auth


def load_s5(parallel: Path) -> Any:
    p=parallel/'sarc5.py';need(sha_file(p)==S5_SHA,'sarc5 changed before import')
    name='sarc6_pinned_sarc5_numerical_implementation'
    spec=importlib.util.spec_from_file_location(name,p)
    need(spec is not None and spec.loader is not None,'Cannot import pinned helper')
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m
    try:spec.loader.exec_module(m)
    except BaseException:
        sys.modules.pop(name,None);raise
    return m


def binding(parallel: Path, executor: Path, auth: dict[str, Any]) -> dict[str, Any]:
    return {'executor_sha256':sha_file(executor),'executor_version':VERSION,'sarc5_sha256':S5_SHA,
            'authorization_sha256':sha_file(parallel/AUTH_REL),'protocol_sha256':sha_file(parallel/PROTOCOL_REL),
            'split_sha256':sha_file(parallel/SPLITS_REL),'preflight_report_sha256':REPORT_SHA,
            'input_complete_sha256':sha_file(parallel/INPUT_RUN/'input_complete.json')}


def close_number(a: Any,b: Any) -> bool:
    return isinstance(a,(int,float)) and not isinstance(a,bool) and math.isfinite(a) and math.isclose(a,b,rel_tol=2e-6,abs_tol=2e-8)


def validate_result(r: dict[str, Any], job: tuple[int,str,int], smoke: bool=False) -> None:
    f,m,s=job
    need(r['model_id']==m and r['seed']==s and r['status']=='PASS', 'Result method/seed/status mismatch')
    need(r['scope']==('ARTIFICIAL_SELFTEST' if smoke else 'SARC_FIXED_MODEL_EXTERNAL'),'Wrong scientific result scope')
    need(len(r['latent'])==50 and all(len(a)==(10 if s==0 else 5) and
         all(isinstance(v,(int,float)) and math.isfinite(v) for v in a) for a in r['latent']),'Invalid latent matrix')
    for family,field in (('reconstruction','reconstruction_nmse'),('omitted_view','omitted_view_nmse')):
        need(set(r[family])==set(VIEWS),'Missing endpoint view')
        for v in VIEWS:
            d=r[family][v];n=d['test_row_counts'];ss=d['test_row_sse']
            need(len(n)==len(ss)==50 and all(type(x) is int and x>0 for x in n),'Missing/invalid observed target counts')
            need(all(isinstance(x,(int,float)) and math.isfinite(x) and x>=0 for x in ss), 'Invalid squared errors')
            need(sum(n)==d['n_observed_test_entries'] and close_number(d['mse'],sum(ss)/sum(n)) and
                 close_number(d['nmse'],d['mse']/max(d['train_null_mse'],1e-12)), 'NMSE arithmetic mismatch')
        need(close_number(r[field],sum(r[family][v]['nmse'] for v in VIEWS)/3),'Equal-view mean mismatch')
    for k in SUMMARY_METRICS:
        need(isinstance(r[k],(int,float)) and math.isfinite(r[k]),'Nonfinite result: '+k)
    need(0<=r['raw_cross_view_mrr']<=1 and 0<=r['adjusted_cross_view_mrr']<=1,'Invalid retrieval result')
    if s:
        e=r['selected_epoch'];a=r['fit_audits']
        need(type(e) is int and 1<=e<=(2 if smoke else 400) and len(a)==2,'Neural epochs/audits missing')
        for x in a:
            need(x['device']=='cuda:0' and x['fit_status']=='PASS' and x['fit_seed']==s and
                 x['variant_id']==m and x['profile_id']=='ARCH_COMPACT__REG_WEAK', 'Neural training identity differs')
        need(a[0]['maximum_epochs']==(2 if smoke else 400) and a[0]['patience']==(2 if smoke else 30) and
             a[0]['selected_epoch']==e and a[1]['selected_epoch']==e and a[1]['epochs_run']==e,
             'Selected epoch/refit not applied exactly')
        need(type(r['neural_heldout_collapse']) is bool,'Missing collapse diagnostic')
    else:
        need(r['selected_epoch'] is None and not r['fit_audits'] and r['neural_heldout_collapse'] is None,'PCA masquerades as neural fit')
    canonical(r)


def validate_inventory(root: Path) -> None:
    if not root.exists():return
    allowed={'execution_start.json','completion_lock.json','technical_stop.json','shards','preprocessing','sessions','summaries'}
    need(all(p.name in allowed for p in root.iterdir()),'Unexpected scientific output/partial publication: inspect without deletion')
    if (root/'shards').exists():
        jobs={job_name(*j) for j in expected_jobs()}
        need(all(p.is_dir() and p.name in jobs for p in (root/'shards').iterdir()),'Unexpected/partial shard directory')
        for p in (root/'shards').iterdir():
            need({q.name for q in p.iterdir()}=={'result.json','receipt.json'},'Incomplete shard: '+p.name)
    if (root/'preprocessing').exists():
        allowed_pre={'fold_%02d.json'%f for f in range(1,6)}
        need(all(p.is_file() and p.name in allowed_pre for p in (root/'preprocessing').iterdir()),'Unexpected preprocessing artifact')
    # Interrupted atomic writes retain their temporary bytes. They must be reviewed.
    need(not any(p.name.startswith('.writing_') for p in root.rglob('*')),'Uncommitted artifact found; preserve it and request review')


def read_shard(root: Path, j: tuple[int,str,int], binds: dict[str,Any], splits: dict[str,Any]) -> dict[str,Any]:
    path=root/'shards'/job_name(*j)
    receipt=load_json(path/'receipt.json');verify_record(path,receipt['result'])
    need(receipt['result']['path']=='result.json' and receipt['bindings']==binds,'Shard provenance mismatch')
    data=load_json(path/'result.json')
    need(data['bindings']==binds and data['fold']==j[0],'Shard source/split mismatch')
    spec=splits['splits'][j[0]-1]
    need(data['test_row_indices']==spec['test'] and data['test_case_ids']==[splits['case_ids'][i] for i in spec['test']],
         'Shard test row alignment mismatch')
    verify_record(root,data['preprocessing'])
    validate_result(data['evaluation'],j)
    return data


def publish_shard(root: Path, j: tuple[int,str,int], data: dict[str,Any]) -> None:
    shardroot=root/'shards';shardroot.mkdir(parents=True,exist_ok=True)
    final=shardroot/job_name(*j)
    need(not final.exists(),'Existing shard cannot be replaced')
    temp=shardroot/('.pending_'+uuid.uuid4().hex);temp.mkdir(exist_ok=False)
    # On hard interruption the pending directory is kept and requires review.
    publish_json(temp/'result.json',data)
    publish_json(temp/'receipt.json',{'bindings':data['bindings'],'result':record(temp/'result.json',temp)})
    need(not final.exists(),'Concurrent shard appeared')
    temp.rename(final)


def preprocessing_record(s5: Any, p: dict[str,Any], split: dict[str,Any], binds: dict[str,Any]) -> dict[str,Any]:
    import numpy as np
    def digest(a):
        x=np.ascontiguousarray(a)
        return {'dtype':str(x.dtype),'shape':list(x.shape),'sha256':hashlib.sha256(x.tobytes()).hexdigest()}
    out={'fold':split['fold'],'bindings':binds,'fit_rows':split['fit'],'early_rows':split['early'],
         'train_rows':split['train'],'test_rows':split['test'],'test_used_for_preprocessing':False,'stages':{}}
    for label in ('prelim','refit'):
        st={'combined_digest':s5.preprocessor_digest(p[label]),'views':{}}
        for v in VIEWS:
            t=p[label]['transforms'][v];pc=p[label]['pcas'][v]
            st['views'][v]={'selected_count':len(t.selected_indices),'selected_indices':digest(t.selected_indices),
                            'medians':digest(t.medians),'means':digest(t.means),'scales':digest(t.scales),
                            'PCA_mean':digest(pc.mean),'PCA_components':digest(pc.components)}
        out['stages'][label]=st
    return out


def csv_bytes(rows: list[dict[str,Any]]) -> bytes:
    need(bool(rows),'Empty summary table')
    h=io.StringIO(newline='');w=csv.DictWriter(h,fieldnames=list(rows[0]),lineterminator='\n')
    w.writeheader();w.writerows(rows);return h.getvalue().encode('utf-8')


def finalize(root: Path, parallel: Path, s5: Any, splits: dict[str,Any], binds: dict[str,Any]) -> dict[str,Any]:
    import numpy as np
    need(not (root/'technical_stop.json').exists(),'Cannot finalize after technical error')
    data={j:read_shard(root,j,binds,splits) for j in expected_jobs()}
    fold_rows=[]; model_rows=[]; contrasts=[];agreements=[]
    for f in range(1,6):
        for m in MODELS:
            vals=[data[(f,m,s)]['evaluation'] for s in ((0,) if m==MODELS[0] else SEEDS)]
            row={'fold':f,'model_id':m,'n_patients':50,'n_seeds':len(vals),'collapse_flags':sum(x['neural_heldout_collapse'] is True for x in vals)}
            row.update({k:sum(x[k] for x in vals)/len(vals) for k in SUMMARY_METRICS})
            for family in ('reconstruction','omitted_view'):
                for v in VIEWS:
                    row[family+'_'+v+'_nmse']=sum(x[family][v]['nmse'] for x in vals)/len(vals)
            fold_rows.append(row)
        for m in NEURAL_MODELS:
            a,b=(np.asarray(data[(f,m,s)]['evaluation']['latent']) for s in SEEDS)
            agreements.append({'fold':f,'model_id':m,**s5.subspace_agreement(a,b)})
    for m in MODELS:
        ff=[r for r in fold_rows if r['model_id']==m]
        row={'model_id':m,'n_folds':5,'n_unique_heldout_patients':250,'n_model_evaluations':5 if m==MODELS[0] else 10,
             'neural_collapse_flag_count':None if m==MODELS[0] else sum(r['collapse_flags'] for r in ff)}
        row.update({k+'_mean':sum(r[k] for r in ff)/5 for k in SUMMARY_METRICS})
        for family in ('reconstruction','omitted_view'):
            for v in VIEWS:
                k=family+'_'+v+'_nmse';row[k+'_mean']=sum(r[k] for r in ff)/5
        model_rows.append(row)
    byfold={(r['fold'],r['model_id']):r for r in fold_rows}
    for left,right in CONTRASTS:
        for metric in SUMMARY_METRICS:
            d=[byfold[(f,left)][metric]-byfold[(f,right)][metric] for f in range(1,6)]
            contrasts.append({'left':left,'right':right,'metric':metric,'direction':'lower better' if metric.endswith('nmse') else 'higher better',
                              'n_paired_folds':5,'mean_left_minus_right':sum(d)/5,
                              **{'fold_%d_delta'%i:val for i,val in enumerate(d,1)},
                              'scope':'descriptive; no p-value or inferential confidence interval'})
    agsum=[]
    for m in NEURAL_MODELS:
        a=[x for x in agreements if x['model_id']==m];vv=[x['value'] for x in a if x['value'] is not None]
        agsum.append({'model_id':m,'n_planned_folds':5,'n_defined_folds':len(vv),
                      'all_folds_mean':sum(vv)/5 if len(vv)==5 else None,
                      'defined_fold_mean_descriptive':sum(vv)/len(vv) if vv else None,
                      'interpretation':'same-fold two-seed only; not resampling stability or q10 retention'})
    summary={'status':COMPLETE_STATUS,'bindings':binds,'n_patients':250,'n_folds':5,'n_evaluations':25,
             'PCA_fits':5,'neural_optimization_stages':40,'failed_evaluations':0,
             'model_selection_performed':False,'cohort_exclusions':0,'historical_results_modified':False,
             'clinical_outcomes_accessed':False,'q10_retention_applied':False,'seed_only_agreement':agsum,
             'aggregation':'two neural seeds averaged within each fold; five equal-sized folds averaged; all planned records required',
             'fold_metric_rows':fold_rows,'model_summaries':model_rows,'paired_descriptive_contrasts':contrasts,
             'limitations':['Independent-cohort refitting, not zero-shot transport of TARGET weights.',
                            'V4 is the representation engine before retention; no biological truth recovery endpoint.',
                            'Limited three-model comparison; budgeted K10 PCA differs from historical all-feature PCA.',
                            'Latent axes are not aligned across folds; never concatenate fold latents as one factor matrix.',
                            'All recorded flags remain included. No p-values or inferential confidence intervals.']}
    tables={'fold_metrics.csv':csv_bytes(fold_rows),'model_summary.csv':csv_bytes(model_rows),
            'paired_descriptive_contrasts.csv':csv_bytes(contrasts),'seed_only_agreement.csv':csv_bytes(agreements),
            'summary.json':canonical(summary)}
    for name,raw in tables.items():verify_or_publish(root/'summaries'/name,raw)
    generated=[record(p,root) for p in sorted(root.rglob('*')) if p.is_file() and
               p.parts[len(root.parts)] in ('shards','preprocessing','summaries')]
    generated.append(record(root/'execution_start.json',root))
    complete={'status':COMPLETE_STATUS,'created_at_utc':now(),'bindings':binds,'n_evaluations':25,
              'n_folds':5,'n_patients':250,'n_failed_evaluations':0,'files':generated}
    publish_json(root/'completion_lock.json',complete)
    return complete


def verify_complete(root: Path, binds: dict[str,Any]) -> dict[str,Any]:
    validate_inventory(root)
    c=load_json(root/'completion_lock.json')
    need(c['status']==COMPLETE_STATUS and c['bindings']==binds and c['n_evaluations']==25 and c['n_failed_evaluations']==0,
         'Completion identity/status differs')
    paths=[r['path'] for r in c['files']]
    need(len(paths)==len(set(paths)),'Duplicate completion record')
    for r in c['files']:verify_record(root,r)
    expected={('shards/'+job_name(*j)+'/'+fn) for j in expected_jobs() for fn in ('result.json','receipt.json')}
    expected|={'preprocessing/fold_%02d.json'%f for f in range(1,6)}
    expected|={'summaries/'+n for n in ('fold_metrics.csv','model_summary.csv','paired_descriptive_contrasts.csv','seed_only_agreement.csv','summary.json')}
    expected.add('execution_start.json')
    need(set(paths)==expected,'Completion file set incomplete/extra')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and
            p.relative_to(root).parts[0] in ('shards','preprocessing','summaries')}
    need(actual==expected-{'execution_start.json'},'Extra/missing results after completion')
    return c


def export_evidence(parallel: Path, root: Path, executor: Path) -> Path:
    """Bounded metadata/results only. No input matrices or raw molecular files."""
    entries={}
    for p in root.rglob('*'):
        if p.is_file() and not p.name.startswith('.'):
            need(p.suffix in ('.json','.csv','.txt'), 'Unexpected evidence payload extension')
            entries['scientific_results/'+p.relative_to(root).as_posix()]=p
    for rel in (AUTH_REL, PROTOCOL_REL, SPLITS_REL, PREFLIGHT_REL, REPORT_REL):
        entries[rel.removeprefix('limited_model_v1/')]=parallel/rel
    for name in ('sarc6.py','sarc6a.py','sarc5.py'):
        entries['sources/'+name]=parallel/name
    need(sum(p.stat().st_size for p in entries.values())<20*1024*1024,'Unexpected evidence size; matrices not exported')
    tag=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
    dest=parallel/('s6small_'+tag+'.zip')
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,p in sorted(entries.items()):
            z.writestr(name,p.read_bytes())
    raw=buf.getvalue();need(len(raw)<=MAX_ZIP,'Evidence exceeds 5 MiB; do not export matrix folder')
    publish_bytes(dest,raw)
    print('Evidence ZIP (send this FILE): '+str(dest),flush=True)
    print('Evidence ZIP bytes: '+str(len(raw)),flush=True)
    print('Evidence ZIP SHA-256: '+sha_file(dest),flush=True)
    return dest


def execute_plan(root: Path, parallel: Path, executor: Path, state: dict[str,Any], binds: dict[str,Any],
                 s5: Any, runtime: dict[str,Any], matrices: dict[str,Any], env: dict[str,Any]) -> None:
    """One immutable record per completed model/seed/fold; no automatic retry."""
    validate_inventory(root)
    need(not (root/'technical_stop.json').exists(),'Prior technical failure marker exists. Preserve it; obtain review before restart.')
    snapshot={'version':VERSION,'bindings':binds,'environment':env,'expected_jobs':[list(j) for j in expected_jobs()],
              'full_budget':True,'real_matrix_values_opened_after_authorization':True}
    verify_or_publish(root/'execution_start.json',canonical(snapshot))
    tag=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
    session=root/'sessions'/tag;session.mkdir(parents=True,exist_ok=False)
    log={'started_at_utc':now(),'bindings':binds,'new_jobs':[],'existing_jobs':[],'status':'RUNNING','current_job':None}
    publish_json(session/'start.json',log)
    completed=False
    try:
        for split in state['splits']['splits']:
            fold=split['fold'];jobs=[j for j in expected_jobs() if j[0]==fold];needed=[]
            for j in jobs:
                if (root/'shards'/job_name(*j)).exists():
                    read_shard(root,j,binds,state['splits']);log['existing_jobs'].append(job_name(*j))
                    print('Fold %d/5 %s seed=%d: VERIFIED_EXISTING PASS'%j,flush=True)
                else:needed.append(j)
            if not needed:continue
            log['current_job']={'fold':fold,'stage':'fold_local_preprocessing'}
            print('Fold %d/5: TRAIN-ONLY preprocessing fit=160 / early=40 / refit=200 / test=50 ...'%fold,flush=True)
            p=s5.prepared_views(runtime,matrices,split)
            audit=preprocessing_record(s5,p,split,binds)
            ap=root/'preprocessing'/('fold_%02d.json'%fold)
            verify_or_publish(ap,canonical(audit))
            for j in needed:
                _,model,seed=j
                log['current_job']={'fold':fold,'model_id':model,'seed':seed,'stage':'fit_and_evaluate'}
                print('Fold %d/5 %s seed=%d: START full frozen budget'%j,flush=True)
                # EXACT tested numerical function, not a copied training implementation.
                r=s5.evaluate_fixed_model(runtime,p,model,seed,smoke=False)
                validate_result(r,j)
                need(sha_file(parallel/'sarc5.py')==S5_SHA,'Numerical helper changed during fit')
                test=split['test']
                payload={'fold':fold,'bindings':binds,'preprocessing':record(ap,root),
                         'test_row_indices':test,'test_case_ids':[state['splits']['case_ids'][i] for i in test],
                         'evaluation':r}
                publish_shard(root,j,payload)
                log['new_jobs'].append(job_name(*j))
                done=len(log['new_jobs'])+len(log['existing_jobs'])
                print('Fold %d/5 %s seed=%d: PASS selected_epoch=%s | completed=%d/25'%(*j,str(r['selected_epoch']),done),flush=True)
            del p;gc.collect()
        log['current_job']={'stage':'final_input_recheck_and_aggregation'}
        # Full final source/metadata check. Molecular byte checks are explicit here.
        after=verify_static(parallel)
        need(after['files']==state['files'],'Inputs changed during scientific execution')
        for v,(rel,digest,width) in state['plan']['input_matrices'].items():
            need(sha_file(parallel/INPUT_RUN/rel)==digest,'Real input changed during run: '+v)
        finalize(root,parallel,s5,state['splits'],binds)
        completed=True;log['status']=COMPLETE_STATUS
        print('All 25 evaluations complete; input/source recheck: PASS',flush=True)
        print('Status: '+COMPLETE_STATUS,flush=True)
        print('Results lock: '+str(root/'completion_lock.json'),flush=True)
    except KeyboardInterrupt:
        log['status']='INTERRUPTED_RESUMABLE_SAME_SOURCES_AND_SEEDS'
        log['traceback']=traceback.format_exc()
        print('INTERRUPTED: completed records preserved. Resume only this unchanged sarc6.py.',flush=True)
        raise
    except Exception as exc:
        log['status']='TECHNICAL_STOP_NO_AUTOMATIC_RETRY';log['error']=type(exc).__name__+': '+str(exc)
        log['traceback']=traceback.format_exc()
        if not (root/'completion_lock.json').exists() and not (root/'technical_stop.json').exists():
            publish_json(root/'technical_stop.json',log)
        raise
    finally:
        log['finished_at_utc']=now()
        publish_json(session/'end.json',log)
        try:export_evidence(parallel,root,executor)
        except Exception as exc:
            print('EVIDENCE EXPORT STOPPED: '+str(exc)+'. Existing outputs were not deleted.',flush=True)
            if completed:print('Scientific completion lock already exists; do not refit.',flush=True)


def main() -> None:
    executor=Path(__file__).resolve();parallel=executor.parent
    need(executor.name=='sarc6.py' and parallel.name=='paper5_parallel_sarc','Keep sarc6.py in paper5_parallel_sarc')
    need(sys.version_info[:2]==(3,10),'Use the existing Python 3.10 interpreter')
    print('SARC6 - exact-source authorized LIMITED real-cohort benchmark',flush=True)
    print('Version: '+VERSION,flush=True)
    with process_lock(parallel/'limited_model_v1'/'.sarc5.lock'):
        state=verify_static(parallel)
        auth=verify_authorization(parallel,executor,state)
        binds=binding(parallel,executor,auth)
        root=parallel/RESULT_REL
        print('Exact sarc5/protocol/splits/synthetic GPU report/authorization: PASS',flush=True)
        print('Execution mode: AUTHORIZED_LIMITED_SARC_FIXED_MODELS',flush=True)
        print('Patients: 250 | folds: 5 | model evaluations: 25 | neural optimization stages: 40 | PCA fits: 5',flush=True)
        print('Clinical/outcomes/retention tuning/historical-result changes: FORBIDDEN',flush=True)
        if (root/'completion_lock.json').exists():
            verify_complete(root,binds)
            print('Existing exact COMPLETE result: VERIFIED. No fitting or input matrix decoding performed.',flush=True)
            export_evidence(parallel,root,executor);return
        validate_inventory(root)
        need(not (root/'technical_stop.json').exists(),'Previous technical failure. Do not delete marker or rerun blindly; send Evidence ZIP.')
        s5=load_s5(parallel)
        runtime=s5.load_runtime(parallel.parent)
        plan=s5.protocol_core(runtime,state['splits']['case_ids']);plan['sarc5_source_sha256']=S5_SHA
        need(s5.json_bytes(plan)==(parallel/PROTOCOL_REL).read_bytes(),'Runtime protocol differs from frozen file')
        rebuilt={'case_ids':state['splits']['case_ids'],'splits':s5.build_splits(state['splits']['case_ids']),
                 'protocol_version':plan['version']}
        need(s5.json_bytes(rebuilt)==(parallel/SPLITS_REL).read_bytes(),'Runtime split reconstruction differs')
        env=s5.cuda_environment()
        for k,v in EXPECTED_ENV.items():need(env.get(k)==v,'Current runtime differs from successful synthetic report: '+k)
        root.mkdir(parents=True,exist_ok=True)
        print('Full-budget runtime/profile: PASS; loading hash-bound real SARC matrices ...',flush=True)
        matrices=s5.load_pointwise_inputs(parallel/INPUT_RUN,s5.INPUT_MATRICES,250)
        try:
            execute_plan(root,parallel,executor,state,binds,s5,runtime,matrices,env)
        finally:s5.close_inputs(matrices)


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:
        print('SARC6 interrupted. Do not delete any output files.');raise SystemExit(130)
    except Exception as exc:
        print('SARC6 STOPPED: '+type(exc).__name__+': '+str(exc))
        traceback.print_exc()
        print('No automatic parameter/seed rescue. Preserve the error and all evidence.');raise SystemExit(2)
