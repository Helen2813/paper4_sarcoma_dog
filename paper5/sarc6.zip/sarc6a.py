from __future__ import annotations

"""Freeze the exact SARC6 executor and previously tested SARC5 protocol.
Standard library only. No model imports, no GPU, no .npy payload reading.
"""
import hashlib
import importlib.util
import sys
from pathlib import Path

sys.dont_write_bytecode = True
VERSION='sarc6a-freeze-exact-limited-external-executor-v1-no-fit'
RUNNER_SHA='3cbd385927713b2f7f792dc1abc975998dad764f6baa62d409e097332a1fc734'


def main() -> None:
    here=Path(__file__).resolve();parallel=here.parent
    if here.name!='sarc6a.py' or parallel.name!='paper5_parallel_sarc':
        raise RuntimeError('Keep sarc6a.py in paper5_parallel_sarc')
    if sys.version_info[:2]!=(3,10):
        raise RuntimeError('Use the existing Python 3.10 interpreter')
    runner=parallel/'sarc6.py'
    if not runner.is_file() or runner.is_symlink() or hashlib.sha256(runner.read_bytes()).hexdigest()!=RUNNER_SHA:
        raise RuntimeError('Exact sarc6.py missing or SHA differs; do not change pinned hashes')
    spec=importlib.util.spec_from_file_location('sarc6_stdlib_authorization_checks',runner)
    if spec is None or spec.loader is None:raise RuntimeError('Cannot load executor metadata checks')
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    print('SARC6A - freeze exact limited SARC execution; NO training',flush=True)
    print('Version: '+VERSION,flush=True)
    before=m.record(here,parallel)
    with m.process_lock(parallel/'limited_model_v1'/'.sarc5.lock'):
        state=m.verify_static(parallel)
        dest=parallel/m.AUTH_REL
        if dest.exists():
            m.verify_authorization(parallel,runner,state)
            print('Existing exact SARC6 authorization: VERIFIED; not rewritten.')
            print('Scientific benchmark started: NO')
            return
        m.need(not (parallel/m.RESULT_REL).exists(), 'Scientific output directory already exists without authorization. Preserve it.')
        print('Exact sarc6 and unchanged sarc5 sources: PASS',flush=True)
        print('Exact local fixed protocol / 250-case split registry / synthetic preflight lock: PASS',flush=True)
        print('Reviewed Windows/CUDA artificial report: 25 records / 40 neural stages / 5 PCA fits: PASS',flush=True)
        print('Historical input/source bindings: PASS (real matrix bytes not opened)',flush=True)
        auth={'status':m.AUTH_STATUS,'created_at_utc':m.now(),'authorizer_version':VERSION,
              'executor':m.record(runner,parallel),'authorizer':before,
              'numerical_implementation_sha256':m.S5_SHA,'historical_inputs':state['files'],
              'scientific_results_rel':m.RESULT_REL,'expected_environment':m.EXPECTED_ENV,
              'scientific_benchmark_started':False,'real_matrix_values_opened':False,
              'historical_files_modified':False,
              'execution_rules':{'numerical_path':'unchanged sarc5 prepared_views and evaluate_fixed_model(smoke=False)',
                                 'neural_maximum_epochs':400,'early_stopping_patience':30,'fixed_neural_seeds':[1103,2207],
                                 'expected_model_evaluations':25,'neural_optimization_stages':40,'PCA_fits':5,
                                 'resume':'verify and reuse committed records; interrupted uncommitted job restarts with same seed and parameters',
                                 'technical_error':'stop immediately, preserve all records and traceback, no automatic retry',
                                 'aggregation':'all planned records required; mean two seeds within fold then mean five equal-sized folds',
                                 'contrasts':'all three model pairs, four common metrics, descriptive only',
                                 'no_new_selection':True,'no_q10_retention_or_biological_truth_claim':True}}
        m.need(m.verify_static(parallel)['files']==state['files'],'Inputs changed during authorization')
        m.need(m.record(here,parallel)==before and m.sha_file(runner)==RUNNER_SHA,'Source changed during authorization')
        m.publish_json(dest,auth)
        m.verify_authorization(parallel,runner,state)
        print('SARC6 source authorization: FROZEN',flush=True)
        print('Authorization: '+str(dest),flush=True)
        print('Authorization SHA-256: '+m.sha_file(dest),flush=True)
        print('Runner SHA-256: '+RUNNER_SHA,flush=True)
        print('Scientific benchmark started: NO',flush=True)
        print('Next permitted command: run sarc6.py unchanged. Do not rerun sarc5.',flush=True)


if __name__=='__main__':
    try:main()
    except Exception as e:
        print('SARC6A AUTHORIZATION STOPPED: '+type(e).__name__+': '+str(e))
        print('Benchmark not started. Do not edit hashes or delete evidence.');raise SystemExit(2)
