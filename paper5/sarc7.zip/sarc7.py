from __future__ import annotations

"""Read-only audit and manuscript tables for the completed, exact SARC6 run.

No command-line arguments. Put beside sarc5/6 in paper5_parallel_sarc.
Reads committed JSON/CSV results and hashes Python source AS BYTES ONLY.
Does NOT import the benchmark, fit models, read molecular .npy, contact a server,
change thresholds, compute inferential p-values/CIs, or modify prior files.
The only numerical linear algebra is replay of small saved TEST latent matrices.
This is a post-results audit, not prospective authorization or a new experiment.
"""

import csv
import hashlib
import io
import json
import math
import os
import platform
import statistics
import sys
import uuid
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

sys.dont_write_bytecode = True
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'

import numpy as np

VERSION = 'sarc7-completed-sarc6-readonly-numeric-audit-manuscript-assets-v1-no-fit'
COMPLETE = 'LIMITED_SARC_FIXED_MODEL_BENCHMARK_COMPLETE_FROZEN'
AUDIT_STATUS = 'SARC7_RESULTS_AUDITED_MANUSCRIPT_ASSETS_READY_NO_NEW_FIT'
MODELS = ('BLOCK_PCA_BUDGETED_K10', 'V1_SHARED_PRIVATE_AE', 'V4_SABLE_MO')
SEEDS = (1103, 2207)
VIEWS = ('RNA', 'METHYLATION', 'CNV')
BUDGETS = {'RNA': 5000, 'METHYLATION': 10000, 'CNV': 5000}
METRICS = ('reconstruction_nmse', 'omitted_view_nmse', 'raw_cross_view_mrr', 'adjusted_cross_view_mrr')
PAIRS = ((MODELS[2], MODELS[1]), (MODELS[1], MODELS[0]), (MODELS[2], MODELS[0]))
SUMMARY_NAMES = ('fold_metrics.csv', 'model_summary.csv', 'paired_descriptive_contrasts.csv',
                 'seed_only_agreement.csv', 'summary.json')
PREFLIGHT_REPORT = 'sessions/session_20261010T025039Z_0d8d8342/report.json'
PINNED = {
    'scientific_results/completion_lock.json': 'ca6f6931de8ef223792488b0dd43b8b66b3a29e010be395466973da080698fc1',
    'authorization_v1/sarc6_source_authorization.json': 'ae1e3869709c0a17acfea0a53fd76273aa73433a475bf3208e2582973c35755a',
    'fixed_protocol.json': 'f3a63188ecbaff4a5164d999d933a5f6481ff7d0560b999022faa38f7a0cfff8',
    'split_registry.json': '78a702ac43d55dd37f8b194b7b7933fb547f09e04cf6333662b57221160377f0',
    'synthetic_preflight_lock.json': 'ed7fb8dc9ffbbe94b0e8749358b859dc706c44f75bc2c1433c2c52d3de343edb',
    PREFLIGHT_REPORT: '0628fce1629fad130e125cc67b2f8d59e3da53ff06c836e96f446b9c15c361b7',
}
SOURCE_PINS = {
    'sarc5.py': 'dd16e547972d8d298491e2d3c5003dea16760e969e9ea846fda5b0f83020f96f',
    'sarc6.py': '3cbd385927713b2f7f792dc1abc975998dad764f6baa62d409e097332a1fc734',
    'sarc6a.py': '1c75ec7c1a5a6e5c3b03d9522e7b662c0aa5ff95f7bc27661195cf67de238533',
}
MAX_JSON_BYTES = 2 * 1024 * 1024
MAX_ZIP_BYTES = 5 * 1024 * 1024


class AuditError(RuntimeError):
    pass


def need(condition: Any, message: str) -> None:
    if not bool(condition):
        raise AuditError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def jb(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8')


def numeric(x: Any) -> bool:
    return type(x) in (int, float) and math.isfinite(x)


def close(a: Any, b: Any, context: str, tol: float = 2e-9) -> None:
    need(numeric(a) and numeric(b) and math.isclose(a, b, rel_tol=tol, abs_tol=tol),
         'Numerical mismatch at ' + context + ': ' + repr(a) + ' versus ' + repr(b))


def average(values: list[float]) -> float:
    need(bool(values) and all(numeric(x) for x in values), 'Missing/nonfinite values; no successful-only averaging.')
    return math.fsum(values) / len(values)


def safe(root: Path, rel: str) -> Path:
    pos = PurePosixPath(rel)
    need(bool(rel) and not pos.is_absolute() and '..' not in pos.parts and '\\' not in rel
         and ':' not in rel, 'Unsafe relative path: ' + repr(rel))
    p = root.joinpath(*pos.parts)
    for item in (p, *p.parents):
        if item == root.parent:
            break
        need(not item.is_symlink(), 'Symlink not permitted in audit inputs: ' + str(item))
    need(p.resolve().is_relative_to(root.resolve()), 'Path escapes audit root.')
    return p


def strict_json(raw: bytes) -> Any:
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, 'Duplicate JSON key: ' + key)
            out[key] = value
        return out
    def bad_constant(x):
        raise AuditError('Nonfinite JSON constant: ' + x)
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=pairs, parse_constant=bad_constant)


class Reader:
    """Limited-root and source-root are explicit. No directory-wide project search."""
    def __init__(self, root: Path, sources: Path):
        self.root, self.sources = root, sources
        self.seen: dict[str, dict[str, Any]] = {}
        self.actual_paths: dict[str, Path] = {}

    def read(self, rel: str, expected: str | None = None, size: int | None = None,
             source: bool = False) -> bytes:
        p = safe(self.sources if source else self.root, rel)
        need(p.is_file(), 'Required file missing: ' + str(p))
        need(0 < p.stat().st_size <= MAX_JSON_BYTES, 'Unexpected input size: ' + str(p))
        data = p.read_bytes()
        digest = sha(data)
        need(expected is None or digest == expected, 'SHA mismatch: ' + str(p))
        need(size is None or len(data) == size, 'Size mismatch: ' + str(p))
        key = ('sources/' if source else '') + rel
        rec = {'path': key, 'sha256': digest, 'size_bytes': len(data)}
        if key in self.seen:
            need(self.seen[key] == rec, 'Input changed while auditing: ' + key)
        self.seen[key], self.actual_paths[key] = rec, p
        return data

    def j(self, rel: str, expected: str | None = None, size: int | None = None) -> Any:
        return strict_json(self.read(rel, expected, size))

    def recheck(self) -> None:
        for key, rec in self.seen.items():
            p = self.actual_paths[key]
            need(p.is_file() and not p.is_symlink(), 'Input disappeared/replaced: ' + key)
            raw = p.read_bytes()
            need(len(raw) == rec['size_bytes'] and sha(raw) == rec['sha256'], 'Input changed: ' + key)


def jobs():
    return [(f, m, s) for f in range(1, 6) for m in MODELS for s in ((0,) if m == MODELS[0] else SEEDS)]


def jobname(f: int, m: str, s: int) -> str:
    return 'F%02d__%s__S%d' % (f, m, s)


def expected_result_paths() -> set[str]:
    paths = {'shards/' + jobname(*j) + '/' + n for j in jobs() for n in ('receipt.json', 'result.json')}
    paths |= {'preprocessing/fold_%02d.json' % f for f in range(1, 6)}
    paths |= {'summaries/' + n for n in SUMMARY_NAMES}
    return paths | {'execution_start.json'}


def validate_splits(registry: dict) -> None:
    ids = registry['case_ids']
    need(len(ids) == len(set(ids)) == 250 and all(isinstance(x, str) and x for x in ids), 'Invalid case list.')
    need(registry['protocol_version'] == 'SARC_LIMITED_FIXED_MODELS_V1', 'Wrong split version.')
    need([x['fold'] for x in registry['splits']] == list(range(1, 6)), 'Wrong fold set/order.')
    all_test = []
    for split in registry['splits']:
        for key, n in [('fit', 160), ('early', 40), ('train', 200), ('test', 50)]:
            ix = split[key]
            need(len(ix) == len(set(ix)) == n and all(type(x) is int and 0 <= x < 250 for x in ix), 'Bad split: ' + key)
        fit, early, train, test = (set(split[k]) for k in ('fit', 'early', 'train', 'test'))
        need(not fit & early and fit | early == train and not train & test
             and train | test == set(range(250)), 'Split leakage or incomplete partition.')
        all_test += split['test']
    need(Counter(all_test) == Counter(range(250)), 'Patients not held out exactly once.')


def replay_nmse(d: dict, width: int) -> float:
    n, ss = d['test_row_counts'], d['test_row_sse']
    need(len(n) == len(ss) == 50 and all(type(x) is int and 0 < x <= width for x in n), 'Invalid observed-entry counts.')
    need(all(numeric(x) and x >= 0 for x in ss), 'Invalid squared error.')
    need(sum(n) == d['n_observed_test_entries'], 'Wrong total count.')
    need(numeric(d['train_null_mse']) and d['train_null_mse'] > 0, 'Nonpositive training-null variance.')
    mse = math.fsum(ss) / sum(n)
    nmse = mse / max(d['train_null_mse'], 1e-12)
    close(d['mse'], mse, 'observed-entry MSE')
    close(d['nmse'], nmse, 'training-normalized NMSE')
    return nmse


def replay_latent(e: dict) -> tuple[np.ndarray, float, float]:
    a = np.asarray(e['latent'], dtype=np.float64)
    need(a.shape == (50, 10 if e['model_id'] == MODELS[0] else 5) and np.isfinite(a).all(), 'Invalid saved latent matrix.')
    centered = a - a.mean(axis=0)
    energies = np.linalg.svd(centered, compute_uv=False) ** 2
    if energies.sum() <= 0:
        rank = 0.0
    else:
        p = energies[energies > 0] / energies.sum()
        rank = float(np.exp(-np.sum(p * np.log(p))))
    variance = float(np.median(np.var(a, axis=0, ddof=1)))
    close(e['latent_effective_rank'], rank, 'effective rank', 2e-8)
    close(e['latent_median_variance'], variance, 'median latent variance', 2e-8)
    flag = bool(rank < 2.0 or variance < 1e-4) if e['model_id'] != MODELS[0] else None
    need(e['neural_heldout_collapse'] is flag, 'Saved collapse flag does not match its definition.')
    return a, rank, variance


def replay_agreement(x: np.ndarray, y: np.ndarray) -> dict:
    def basis(a):
        a = a - a.mean(axis=0)
        u, s, _ = np.linalg.svd(a, full_matrices=False)
        tol = max(a.shape) * np.finfo(float).eps * (s[0] if len(s) else 0.0)
        return u[:, s > tol]
    a, b = basis(x), basis(y)
    if min(a.shape[1], b.shape[1]) == 0:
        return {'status': 'UNDEFINED_ZERO_RANK', 'value': None, 'rank_left': a.shape[1], 'rank_right': b.shape[1]}
    return {'status': 'DESCRIPTIVE_SEED_ONLY', 'value': float(np.clip(np.linalg.svd(a.T @ b, compute_uv=False), 0, 1).mean()),
            'rank_left': a.shape[1], 'rank_right': b.shape[1]}


def compare_objects(actual: Any, expected: Any, path: str = 'root') -> None:
    if expected is None or type(expected) is bool or isinstance(expected, str):
        need(actual == expected and type(actual) is type(expected), 'Value/type differs: ' + path)
    elif type(expected) in (int, float):
        close(actual, expected, path, 2e-8)
    elif isinstance(expected, list):
        need(isinstance(actual, list) and len(actual) == len(expected), 'List length/type differs: ' + path)
        for i, (a, b) in enumerate(zip(actual, expected)):
            compare_objects(a, b, path + '/' + str(i))
    elif isinstance(expected, dict):
        need(isinstance(actual, dict) and set(actual) == set(expected), 'Dictionary keys differ: ' + path)
        for k in expected:
            compare_objects(actual[k], expected[k], path + '/' + k)
    else:
        raise AuditError('Unsupported object in comparison: ' + path)


def compare_csv(raw: bytes, rows: list[dict], name: str) -> None:
    h = io.StringIO(raw.decode('utf-8-sig'), newline='')
    dr = csv.DictReader(h)
    need(dr.fieldnames == list(rows[0]), 'CSV columns differ: ' + name)
    old = list(dr)
    need(len(old) == len(rows), 'CSV row count differs: ' + name)
    for i, (a, b) in enumerate(zip(old, rows)):
        for k, v in b.items():
            pos = name + '/' + str(i) + '/' + k
            if v is None:
                need(a[k] == '', 'Expected blank in ' + pos)
            elif type(v) in (float, int):
                close(float(a[k]), v, pos, 2e-8)
            else:
                need(a[k] == str(v), 'CSV value differs: ' + pos)


def audit(reader: Reader) -> dict[str, Any]:
    pinned = {rel: reader.j(rel, digest) for rel, digest in PINNED.items()}
    for name, digest in SOURCE_PINS.items():
        reader.read(name, digest, source=True)
    lock = pinned['scientific_results/completion_lock.json']
    auth = pinned['authorization_v1/sarc6_source_authorization.json']
    protocol = pinned['fixed_protocol.json']
    registry = pinned['split_registry.json']
    prelock = pinned['synthetic_preflight_lock.json']
    pre = pinned[PREFLIGHT_REPORT]
    validate_splits(registry)
    need(lock['status'] == COMPLETE and lock['n_evaluations'] == 25 and lock['n_failed_evaluations'] == 0
         and lock['n_folds'] == 5 and lock['n_patients'] == 250, 'Completion not valid.')
    need(auth['status'] == 'FROZEN_LIMITED_SARC_EXECUTION_AUTHORIZATION', 'Missing source authorization.')
    b = lock['bindings']
    mapping = {'authorization_sha256': 'authorization_v1/sarc6_source_authorization.json',
               'protocol_sha256': 'fixed_protocol.json', 'split_sha256': 'split_registry.json',
               'preflight_report_sha256': PREFLIGHT_REPORT}
    for k, rel in mapping.items():
        need(b[k] == PINNED[rel], 'Bad completion binding: ' + k)
    need(b['executor_sha256'] == SOURCE_PINS['sarc6.py'] and b['sarc5_sha256'] == SOURCE_PINS['sarc5.py'], 'Source bindings differ.')
    need(auth['executor']['sha256'] == SOURCE_PINS['sarc6.py'] and auth['authorizer']['sha256'] == SOURCE_PINS['sarc6a.py'], 'Authorizer source differs.')
    need(protocol['input_complete_sha256'] == b['input_complete_sha256'], 'Input manifest binding differs.')
    need(prelock['protocol_sha256'] == b['protocol_sha256'] and prelock['split_sha256'] == b['split_sha256']
         and prelock['source_sha256'] == SOURCE_PINS['sarc5.py'], 'Preflight lock bindings differ.')
    need(pre['status'] == 'LIMITED_PROTOCOL_AND_SYNTHETIC_PATH_PASS_NOT_AUTHORIZED', 'Synthetic report not PASS.')
    need(protocol['models'] == list(MODELS) and protocol['CV']['neural_fit_seeds'] == list(SEEDS), 'Model/seed protocol differs.')
    need(protocol['neural_profile']['maximum_epochs'] == 400 and protocol['CV']['repeats'] == 1, 'Budget differs.')
    records = lock['files']; names = [x['path'] for x in records]
    need(len(names) == len(set(names)) == 61 and set(names) == expected_result_paths(), 'Wrong committed result inventory.')
    sr = reader.root / 'scientific_results'
    need(not (sr / 'technical_stop.json').exists(), 'Technical stop marker exists; do not remove it.')
    actual = {p.relative_to(sr).as_posix() for prefix in ('shards', 'preprocessing', 'summaries')
              for p in (sr / prefix).rglob('*') if p.is_file()}
    need(actual == expected_result_paths() - {'execution_start.json'}, 'Extra/missing result files or pending shards.')
    loaded = {}
    for rec in records:
        rel = 'scientific_results/' + rec['path']
        raw = reader.read(rel, rec['sha256'], rec['size_bytes'])
        loaded[rec['path']] = strict_json(raw) if rel.endswith('.json') else raw
    start = loaded['execution_start.json']
    need(start['bindings'] == b and start['full_budget'] is True, 'Execution-start bindings/budget differ.')
    need(start['expected_jobs'] == [list(j) for j in jobs()], 'Execution schedule differs.')
    for k, v in auth['expected_environment'].items():
        need(start['environment'].get(k) == v, 'Recorded execution environment differs: ' + k)
    prep_rows = []
    for f in range(1, 6):
        p = loaded['preprocessing/fold_%02d.json' % f]; split = registry['splits'][f-1]
        need(p['fold'] == f and p['bindings'] == b and p['test_used_for_preprocessing'] is False, 'Preprocessing identity/boundary differs.')
        for k in ('fit', 'early', 'train', 'test'):
            need(p[k + '_rows'] == split[k], 'Wrong recorded preprocessing rows: ' + k)
        for stage in ('prelim', 'refit'):
            for view in VIEWS:
                q = p['stages'][stage]['views'][view]
                need(q['selected_count'] == BUDGETS[view], 'Feature budget not reached.')
                for key in ('selected_indices', 'medians', 'means', 'scales', 'PCA_mean'):
                    need(q[key]['shape'] == [BUDGETS[view]], 'Preprocessor array shape differs: ' + key)
                need(q['PCA_components']['shape'] == [10, BUDGETS[view]], 'PCA geometry differs.')
                prep_rows.append({'fold': f, 'stage': stage, 'view': view, 'selected_features': q['selected_count'],
                                  'training_rows': len(split['fit' if stage == 'prelim' else 'train']), 'test_rows_used': False})
    evaluations, latent, epochs, nmse_checks, diagnostics = {}, {}, [], [], []
    masks, denominators = {}, {}
    for job in jobs():
        f, m, seed = job
        name = jobname(*job); data = loaded['shards/' + name + '/result.json']
        receipt = loaded['shards/' + name + '/receipt.json']
        need(receipt['bindings'] == b and data['bindings'] == b and data['fold'] == f, 'Shard bindings differ: ' + name)
        desc = receipt['result']
        need(desc['path'] == 'result.json', 'Receipt result path differs.')
        reader.read('scientific_results/shards/' + name + '/result.json', desc['sha256'], desc['size_bytes'])
        split = registry['splits'][f-1]
        need(data['test_row_indices'] == split['test'] and data['test_case_ids'] == [registry['case_ids'][i] for i in split['test']], 'Test identity mismatch.')
        pr = data['preprocessing']
        need(pr['path'] == 'preprocessing/fold_%02d.json' % f, 'Wrong preprocessing reference.')
        reader.read('scientific_results/' + pr['path'], pr['sha256'], pr['size_bytes'])
        e = data['evaluation']
        need(e['status'] == 'PASS' and e['scope'] == 'SARC_FIXED_MODEL_EXTERNAL' and e['model_id'] == m and e['seed'] == seed, 'Invalid evaluation: ' + name)
        for family, field in (('reconstruction', 'reconstruction_nmse'), ('omitted_view', 'omitted_view_nmse')):
            vals = []
            need(set(e[family]) == set(VIEWS), 'Missing endpoint modality.')
            for view in VIEWS:
                d = e[family][view]; vals.append(replay_nmse(d, BUDGETS[view]))
                key = (f, view)
                if key in masks:
                    need(d['test_row_counts'] == masks[key], 'Models used different observed-target counts.')
                    close(d['train_null_mse'], denominators[key], 'common training-null normalizer')
                else:
                    masks[key], denominators[key] = d['test_row_counts'], d['train_null_mse']
                nmse_checks.append({'fold': f, 'model_id': m, 'seed': seed, 'family': family, 'view': view,
                                    'observed_entries': sum(d['test_row_counts']), 'nmse_replayed': vals[-1]})
            close(e[field], average(vals), 'equal-view average')
        raw = e['raw_cross_view_mrr']; adj = e['adjusted_cross_view_mrr']
        need(numeric(raw) and numeric(adj) and 0 <= raw <= 1 and 0 <= adj <= 1, 'Invalid MRR.')
        random_mrr = math.fsum(1.0/i for i in range(1, 51)) / 50
        close(adj, min(1.0, max(0.0, (raw - random_mrr)/(1 - random_mrr))), 'MRR harmonic-null adjustment')
        a, rank, variance = replay_latent(e); latent[job] = a
        diagnostics.append({'fold': f, 'model_id': m, 'seed': seed, 'effective_rank': rank,
                            'median_latent_variance': variance, 'neural_collapse_flag': e['neural_heldout_collapse']})
        audits = e['fit_audits']
        if seed:
            need(len(audits) == 2, 'Expected two training stages.')
            ea, ra = audits; ep = e['selected_epoch']
            need(type(ep) is int and 1 <= ep <= 400, 'Bad selected epoch.')
            for entry in audits:
                need(entry['fit_status'] == 'PASS' and entry['device'] == 'cuda:0' and entry['fit_seed'] == seed
                     and entry['variant_id'] == m, 'Training stage identity/status differs.')
            need(ea['fit_stage'] == 'confirmatory_early_stop' and ra['fit_stage'] == 'confirmatory_refit_full_training_fold', 'Stage labels differ.')
            need(ea['maximum_epochs'] == 400 and ea['patience'] == 30 and ea['min_delta'] == 0.0001, 'Early-stopping policy differs.')
            need(ep == ea['selected_epoch'] == ra['selected_epoch'] == ra['epochs_run'] and ep <= ea['epochs_run'] <= 400, 'Epoch/refit inconsistency.')
            need(ea['early_stopped'] is (ea['epochs_run'] < 400), 'Early-stop flag differs.')
            epochs.append({'fold': f, 'model_id': m, 'seed': seed, 'early_epochs_run': ea['epochs_run'],
                           'selected_epoch': ep, 'refit_epochs_run': ra['epochs_run'],
                           'selected_at_cap': ep == 400, 'early_stopped_before_cap': ea['early_stopped'],
                           'best_early_stop_objective': ea['best_early_stop_objective'],
                           'final_early_stop_objective': ea['final_early_stop_objective']})
        else:
            need(audits == [] and e['selected_epoch'] is None and e['neural_heldout_collapse'] is None, 'PCA not applicable fields differ.')
        evaluations[job] = e
    fold_rows, model_rows, contrast_rows, agreements = [], [], [], []
    for f in range(1, 6):
        for m in MODELS:
            vals = [evaluations[(f, m, seed)] for seed in ((0,) if m == MODELS[0] else SEEDS)]
            row = {'fold': f, 'model_id': m, 'n_patients': 50, 'n_seeds': len(vals),
                   'collapse_flags': sum(v['neural_heldout_collapse'] is True for v in vals)}
            row.update({k: average([v[k] for v in vals]) for k in METRICS})
            for family in ('reconstruction', 'omitted_view'):
                for view in VIEWS:
                    row[family + '_' + view + '_nmse'] = average([v[family][view]['nmse'] for v in vals])
            fold_rows.append(row)
        for m in MODELS[1:]:
            agreements.append({'fold': f, 'model_id': m, **replay_agreement(latent[(f, m, SEEDS[0])], latent[(f, m, SEEDS[1])])})
    for m in MODELS:
        ff = [r for r in fold_rows if r['model_id'] == m]
        row = {'model_id': m, 'n_folds': 5, 'n_unique_heldout_patients': 250,
               'n_model_evaluations': 5 if m == MODELS[0] else 10,
               'neural_collapse_flag_count': None if m == MODELS[0] else sum(r['collapse_flags'] for r in ff)}
        row.update({k + '_mean': average([r[k] for r in ff]) for k in METRICS})
        for family in ('reconstruction', 'omitted_view'):
            for v in VIEWS:
                k = family + '_' + v + '_nmse'; row[k + '_mean'] = average([r[k] for r in ff])
        model_rows.append(row)
    byfold = {(x['fold'], x['model_id']): x for x in fold_rows}
    for left, right in PAIRS:
        for metric in METRICS:
            delta = [byfold[(f, left)][metric] - byfold[(f, right)][metric] for f in range(1, 6)]
            contrast_rows.append({'left': left, 'right': right, 'metric': metric,
                'direction': 'lower better' if metric.endswith('nmse') else 'higher better', 'n_paired_folds': 5,
                'mean_left_minus_right': average(delta), **{'fold_%d_delta' % i: val for i, val in enumerate(delta, 1)},
                'scope': 'descriptive; no p-value or inferential confidence interval'})
    computed_tables = dict(zip(SUMMARY_NAMES[:4], (fold_rows, model_rows, contrast_rows, agreements)))
    for name, rows in computed_tables.items():
        compare_csv(loaded['summaries/' + name], rows, name)
    summary = loaded['summaries/summary.json']
    need(summary['bindings'] == b and summary['status'] == COMPLETE and summary['n_evaluations'] == 25
         and summary['failed_evaluations'] == 0 and summary['n_patients'] == 250, 'Summary status/count differs.')
    for key in ('model_selection_performed', 'historical_results_modified', 'clinical_outcomes_accessed', 'q10_retention_applied'):
        need(summary[key] is False, 'Unexpected scope: ' + key)
    need(summary['cohort_exclusions'] == 0 and summary['PCA_fits'] == 5 and summary['neural_optimization_stages'] == 40, 'Summary counts differ.')
    for key, values in [('fold_metric_rows', fold_rows), ('model_summaries', model_rows), ('paired_descriptive_contrasts', contrast_rows)]:
        compare_objects(summary[key], values, key)
    agreement_summary = []
    for m in MODELS[1:]:
        vals = [a['value'] for a in agreements if a['model_id'] == m and a['value'] is not None]
        agreement_summary.append({'model_id': m, 'n_planned_folds': 5, 'n_defined_folds': len(vals),
            'all_folds_mean': average(vals) if len(vals) == 5 else None,
            'defined_fold_mean_descriptive': average(vals) if vals else None,
            'interpretation': 'same-fold two-seed only; not resampling stability or q10 retention'})
    compare_objects(summary['seed_only_agreement'], agreement_summary, 'agreement summary')
    reader.recheck()
    return {'bindings': b, 'fold_rows': fold_rows, 'model_rows': model_rows, 'contrast_rows': contrast_rows,
            'agreements': agreements, 'agreement_summary': agreement_summary, 'epochs': epochs,
            'latent_diagnostics': diagnostics, 'preprocessing': prep_rows, 'nmse_checks': nmse_checks,
            'protocol': protocol, 'inputs_verified': list(reader.seen.values()),
            'checks': {'completion_manifest_files': 61, 'committed_results': 25, 'receipts': 25,
                       'preprocessing_folds': 5, 'unique_heldout_cases': 250, 'replayed_view_endpoints': len(nmse_checks),
                       'replayed_latent_diagnostics': 25, 'replayed_seed_agreements': 10,
                       'replayed_summary_CSVs': 4, 'replayed_summary_JSON': True,
                       'raw_retrieval_recomputed_from_view_embeddings': False,
                       'raw_molecular_matrices_read': False, 'trained_weights_reexecuted': False,
                       'full_learning_curves_present': False}}


def csvb(rows: list[dict]) -> bytes:
    need(bool(rows), 'Empty table.')
    h = io.StringIO(newline=''); w = csv.DictWriter(h, fieldnames=list(rows[0]), lineterminator='\n')
    w.writeheader(); w.writerows(rows)
    return h.getvalue().encode('utf-8')


def make_assets(result: dict) -> dict[str, bytes]:
    model_rows, ff = result['model_rows'], result['fold_rows']
    bymodel = {r['model_id']: r for r in model_rows}
    agreements = {r['model_id']: r['all_folds_mean'] for r in result['agreement_summary']}
    compact = []
    for m in MODELS:
        row = {'model_id': m, 'n_folds': 5, 'n_seeds_per_fold': 1 if m == MODELS[0] else 2}
        for k in METRICS:
            vals = [x[k] for x in ff if x['model_id'] == m]
            row[k + '_mean'] = average(vals)
            row[k + '_fold_SD_descriptive_not_CI'] = statistics.stdev(vals)
        row['two_seed_subspace_agreement_mean'] = agreements.get(m)
        row['neural_collapse_flags'] = bymodel[m]['neural_collapse_flag_count']
        row['scope'] = 'fixed-budget descriptive external application; V4 before retention'
        compact.append(row)
    consistency = []
    for c in result['contrast_rows']:
        d = [c['fold_%d_delta' % f] for f in range(1, 6)]
        lower = c['metric'].endswith('nmse')
        consistency.append({'left': c['left'], 'right': c['right'], 'metric': c['metric'],
          'mean_left_minus_right': c['mean_left_minus_right'],
          'folds_favoring_left': sum(x < 0 if lower else x > 0 for x in d),
          'folds_favoring_right': sum(x > 0 if lower else x < 0 for x in d),
          'ties': sum(x == 0 for x in d), 'scope': 'descriptive signs, not independent tests'})
    per_view = []
    for m in MODELS:
        for v in VIEWS:
            per_view.append({'model_id': m, 'view': v,
                'reconstruction_nmse': bymodel[m]['reconstruction_' + v + '_nmse_mean'],
                'omitted_view_nmse': bymodel[m]['omitted_view_' + v + '_nmse_mean'], 'n_folds': 5})
    ep = result['epochs']
    epoch_counts = {'n_neural_evaluations': len(ep), 'early_runs_reached_cap': sum(x['early_epochs_run'] == 400 for x in ep),
                    'selected_at_400': sum(x['selected_epoch'] == 400 for x in ep),
                    'selected_at_399': sum(x['selected_epoch'] == 399 for x in ep),
                    'early_stopped_before_cap': sum(x['early_stopped_before_cap'] for x in ep),
                    'numerical_convergence_claimed': False, 'extra_epochs_authorized': False}
    table = ['| Model | Reconstruction NMSE ↓ | Omitted-view NMSE ↓ | Raw MRR ↑ | Adjusted MRR ↑ |',
             '|---|---:|---:|---:|---:|']
    for r in model_rows:
        table.append('| %s | %.6f | %.6f | %.6f | %.6f |' % (r['model_id'], *(r[k+'_mean'] for k in METRICS)))
    v1, v4, pca = (bymodel[x] for x in (MODELS[1], MODELS[2], MODELS[0]))
    en = f'''# Limited TCGA-SARC external application: manuscript text

## Methods
A fixed, outcome-blind external application used 250 metadata-selected primary-tumor cases with matched RNA, methylation and CNV. Five fixed folds held out 50 cases each. For neural epoch selection, the 200 outer-training cases were divided into 160 fit and 40 early-stopping cases. Preprocessing was fitted on the 160 fit cases for epoch selection, then independently refitted on all 200 training cases for the final same-seed reinitialization and refit. Two seeds (1103 and 2207) were used for each of V1_SHARED_PRIVATE_AE and the pre-retention V4_SABLE_MO representation engine; BLOCK_PCA_BUDGETED_K10 was fitted once per fold. The fixed primary feature budgets were 5000 RNA, 10000 methylation, and 5000 CNV features, selected using training-only filtering and pre-standardization variance. All 25 planned evaluations were retained; no new patient exclusions or model selection were performed.

All three models were evaluated on the same train-selected standardized molecular-feature targets. Neural predictions were inverse-projected from their per-view PCA coordinates. For each view, squared error was summed over observed test entries, divided by their count, and normalized by the centered observed-entry training variance (floor 1e-12). The three view-specific NMSEs were averaged with equal weight. In omitted-view evaluation the target view was withheld from the prediction inputs. This normalizer is a TRAINING reference: NMSE below 1 is not by itself a comparison with a directly evaluated test-set mean predictor and is not an R-squared estimate. Cross-view retrieval used the frozen six-direction same-patient MRR definition, with harmonic-null adjustment for 50 test candidates. Neural seeds were averaged within fold and folds then averaged equally. Fold SDs, when shown, are descriptive dispersion, not confidence intervals.

## Results
All 25 evaluations completed. Reconstruction NMSE was {pca['reconstruction_nmse_mean']:.3f}, {v1['reconstruction_nmse_mean']:.3f}, and {v4['reconstruction_nmse_mean']:.3f} for budgeted PCA, V1, and V4, respectively; omitted-view NMSE was {pca['omitted_view_nmse_mean']:.3f}, {v1['omitted_view_nmse_mean']:.3f}, and {v4['omitted_view_nmse_mean']:.3f}. Adjusted cross-view MRR was {pca['adjusted_cross_view_mrr_mean']:.3f}, {v1['adjusted_cross_view_mrr_mean']:.3f}, and {v4['adjusted_cross_view_mrr_mean']:.3f}. V4 had higher adjusted retrieval and lower omitted-view NMSE than V1 in all five folds, but higher ordinary reconstruction NMSE in all five. Budgeted PCA had lower overall reconstruction and omitted-view NMSE than both neural models in all five folds. V4 had higher adjusted retrieval than PCA in four of five folds, not all five.

Same-fold two-seed subspace agreement averaged {agreements[MODELS[1]]:.3f} for V1 and {agreements[MODELS[2]]:.3f} for V4. No neural held-out collapse flags were recorded (0/10 for each neural model); the PCA field was not applicable rather than zero. All {epoch_counts['early_runs_reached_cap']} neural epoch-selection stages reached the 400-epoch cap; {epoch_counts['selected_at_400']} selected epoch 400 and {epoch_counts['selected_at_399']} selected epoch 399. The comparison is therefore explicitly training-budget-limited and does not establish numerical convergence or performance after longer optimization.

## Interpretation and limitations
These results show an endpoint-dependent trade-off in this limited external application, not a universal model ranking. The new SARC endpoints share an assessment space within this experiment but do not retroactively harmonize older simulation or TARGET scores. PCA K=10 and neural shared dimension=5/private dimension=2 per view are the frozen model settings, not equal-capacity models. No causal attribution to one V4 component is made from the V1-to-V4 contrast, since several training components differ. This is cohort-specific refitting, not zero-shot transport of TARGET weights. Same-fold two-seed agreement is not full resampling stability, factor identity, or q10 retention validation. No biological ground truth, outcomes, subtype labels, or new p-values/inferential intervals were used. The five folds share training observations; seeds and folds are not independent external cohorts. These results neither change the historical TARGET selection nor repair historical D05/correlated-private limitations.
'''
    counts = result['checks']
    ru = f'''# SARC6: проверка завершённого ограниченного внешнего эксперимента

Это отдельный аудит после получения результатов, не новый эксперимент и не авторизация. Исходные записи сохранены.

## Целостность и арифметика
- {counts['completion_manifest_files']}/61 записей completion lock проверены по точным SHA-256 и размерам.
- 25 уникальных оценок, 25 receipts, 5 preprocessing-записей; 250 пациентов по одному разу в test.
- Пересчитаны 150 view-specific endpoint записей из 7500 сохранённых SSE/count пар; затем равные средние модальностей, seeds и folds.
- Воспроизведены все четыре CSV и численные разделы summary JSON.
- Пересчитаны 25 effective ranks/median variances и 10 same-fold two-seed subspace agreement по сохранённым latent-матрицам.
- Проверено совпадение observed-target counts и training-null normalizers между моделями внутри каждого fold/view.

## Числа
{chr(10).join(table)}

Полная арифметика находится в replay_*.csv. Порядок усреднения: 2 neural seeds внутри fold, затем 5 folds; PCA имеет 1 seedless fit на fold. Пары и метрики сохранены из первоначального SARC-протокола. Подсчёт знаков по folds и epoch-cap summary — описательные дополнения этого аудита, не новые критерии выбора.

V4 лучше V1 по retrieval и omitted-view NMSE в 5/5 folds, хуже по ordinary reconstruction в 5/5. PCA лучше обеих нейронных моделей по суммарным reconstruction/omitted-view NMSE в 5/5 folds. Retrieval V4 выше PCA в 4/5 folds. Никаких утверждений о статистической значимости.

## Обязательные ограничения
- Все {epoch_counts['early_runs_reached_cap']}/20 early-stopping stages дошли до максимума 400; {epoch_counts['selected_at_400']} выбрали 400 и {epoch_counts['selected_at_399']} — 399. Не объявляем сходимость и не увеличиваем бюджет задним числом.
- При выборе 400 значение удовлетворяло исходному правилу min_delta, но полных learning curves здесь нет.
- Ноль neural collapse flags относится к 20 held-out SARC оценкам, не ко всей Paper 5 и не к биологической истинности.
- Два seeds характеризуют воспроизводимость подпространства при инициализации; это не resampling stability и не q10 gate.
- V4 здесь pre-retention. Поле stability_gate=true в исходной VariantSpec само по себе не означает применения post-fit gate.
- NMSE использует training variance, поэтому NMSE>1 не доказывает проигрыш реальному test-mean baseline; это превышение выбранного training-reference масштаба.
- PCA/нейронные модели имеют разные latent-геометрии; это фиксированные процедуры, а не равная ёмкость.
- Fold 5 сохранён, как и все остальные; повышенная CNV-ошибка не является основанием исключать его.

## Границы проверки
Сами molecular .npy, preprocessing arrays и обученные веса не перечитывались. Проверены записанные привязки и сводки, не повторен model fitting. Raw MRR не восстановлен из per-view embeddings: они не входят в пакет; его корректировка и агрегация воспроизведены. Кривые обучения не сохранены. Контроль patient-disjointness и записанных training-only решений не заменяет повторного вычисления preprocessing.

sarc7.py не импортирует sarc5/6 или исторические Python-скрипты. Читает только JSON/CSV и байты трёх исходников. Не обращается к сети, clinical/outcomes, R, Torch/CUDA. Сохранённые TEST latent-матрицы декодируются только для небольших численных перепроверок.

## Следующий шаг
Ограниченный вычислительный блок SARC завершён. Сохранить таблицу, Methods/Results/Limitations и сводку ограничений в workshop-материалах. Старый sarc6 и все исторические результаты не перезапускать и не править.
'''
    tex = ['% SARC fixed-budget descriptive application; V4 BEFORE retention.',
           '% No p-values or confidence intervals; no universal winner.',
           r'\begin{tabular}{lrrr}', r'\hline',
           r'Model & Reconstruction NMSE & Omitted-view NMSE & Adjusted MRR \\', r'\hline']
    for row, label in zip(model_rows, ('Budgeted block PCA (K=10)', 'V1 shared/private AE', 'V4 pre-retention')):
        tex.append('%s & %.3f & %.3f & %.3f \\\\' % (label, row['reconstruction_nmse_mean'], row['omitted_view_nmse_mean'], row['adjusted_cross_view_mrr_mean']))
    tex += [r'\hline', r'\end{tabular}', '% Lower NMSE is better; higher MRR is better. Seeds averaged within folds first.']
    audit_doc = {'status': AUDIT_STATUS, 'version': VERSION, 'post_results_descriptive_audit': True,
       'checks': counts, 'bindings': result['bindings'], 'epoch_cap_summary': epoch_counts,
       'inputs_verified': result['inputs_verified'], 'new_model_fits': 0, 'historical_writes': False,
       'p_values_or_inferential_CI_created': False, 'universal_winner_declared': False,
       'python': sys.version, 'numpy': np.__version__, 'platform': platform.platform()}
    files = {'README_RU.md': ru.encode('utf-8'), 'MANUSCRIPT_TEXT_EN.md': en.encode('utf-8'),
        'sarc_table.tex': ('\n'.join(tex)+'\n').encode(), 'audit.json': jb(audit_doc),
        'manuscript_table.csv': csvb(compact), 'per_view_results.csv': csvb(per_view),
        'fold_direction_summary.csv': csvb(consistency), 'epoch_diagnostics.csv': csvb(ep),
        'latent_diagnostics.csv': csvb(result['latent_diagnostics']), 'preprocessing_bindings.csv': csvb(result['preprocessing']),
        'nmse_arithmetic_replay.csv': csvb(result['nmse_checks']), 'input_fingerprints.csv': csvb(result['inputs_verified'])}
    for name, rows in zip(SUMMARY_NAMES[:4], (result['fold_rows'], result['model_rows'], result['contrast_rows'], result['agreements'])):
        files['replay_' + name] = csvb(rows)
    return files


def publish_new(parallel: Path, files: dict[str, bytes], reader: Reader, source: bytes) -> tuple[Path, Path]:
    reader.recheck()
    tag = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    folder = parallel / 'manuscript_assets_v1' / ('sarc7_' + tag)
    dest = parallel / ('s7small_' + tag + '.zip')
    folder.mkdir(parents=True, exist_ok=False)
    package = dict(files)
    package['sarc7.py'] = source
    manifest = {'status': AUDIT_STATUS, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                'script_sha256': sha(source), 'input_completion_sha256': PINNED['scientific_results/completion_lock.json'],
                'files': [{'path': n, 'sha256': sha(v), 'size_bytes': len(v)} for n, v in sorted(package.items())]}
    package['sarc7_assets_manifest.json'] = jb(manifest)
    for name, raw in package.items():
        with safe(folder, name).open('xb') as f:
            f.write(raw); f.flush(); os.fsync(f.fileno())
    reader.recheck()
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in sorted(package.items()):
            z.writestr(name, raw)
    raw = out.getvalue()
    need(len(raw) <= MAX_ZIP_BYTES, 'Unexpected evidence size: do not send matrix/result folders.')
    with dest.open('xb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    return folder, dest


def main() -> None:
    here = Path(__file__).resolve(); parallel = here.parent
    need(here.name == 'sarc7.py' and parallel.name == 'paper5_parallel_sarc',
         'Put unchanged sarc7.py in paper5_parallel_sarc, not in paper5/scripts.')
    need(len(sys.argv) == 1, 'No command-line options. No refitting is supported.')
    print('SARC7 - completed-results audit and manuscript assets; NO new fitting', flush=True)
    reader = Reader(parallel / 'limited_model_v1', parallel)
    result = audit(reader)
    print('Pinned completion + all 61 result files + source/authorization bindings: PASS', flush=True)
    print('25 evaluations / 250 unique test cases / 5 folds: PASS', flush=True)
    print('150 view endpoints / summary arithmetic / 25 latent diagnostics / 10 seed agreements: PASS', flush=True)
    print('Recorded epoch selection: %d/20 at 400; %d/20 at 399. No retuning.' % (
          sum(x['selected_epoch'] == 400 for x in result['epochs']),
          sum(x['selected_epoch'] == 399 for x in result['epochs'])), flush=True)
    for row in result['model_rows']:
        print('%s: reconstruction=%.6f omitted=%.6f adjusted_MRR=%.6f' %
              (row['model_id'], row['reconstruction_nmse_mean'], row['omitted_view_nmse_mean'], row['adjusted_cross_view_mrr_mean']), flush=True)
    folder, archive = publish_new(parallel, make_assets(result), reader, here.read_bytes())
    print('Source results rechecked unchanged: PASS', flush=True)
    print('Status: ' + AUDIT_STATUS, flush=True)
    print('Assets: ' + str(folder), flush=True)
    print('Evidence ZIP (send this FILE): ' + str(archive), flush=True)
    print('Evidence ZIP bytes: ' + str(archive.stat().st_size), flush=True)
    print('Evidence ZIP SHA-256: ' + sha(archive.read_bytes()), flush=True)
    print('No model execution, raw molecular-matrix access, authorization, or historical rewrite.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('AUDIT INTERRUPTED. Existing results were not modified. No benchmark was launched.', file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print('SARC7 AUDIT STOPPED: %s: %s' % (type(exc).__name__, exc), file=sys.stderr)
        print('Do not edit hashes, remove source evidence, or rerun sarc6 to fix this audit.', file=sys.stderr)
        sys.exit(1)
